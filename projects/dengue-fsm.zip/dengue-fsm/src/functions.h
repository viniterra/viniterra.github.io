#ifndef _FUNCTIONS_H
#define _FUNCTIONS_H

#include <stdlib.h>
#include <stdio.h>

float geraCoordenada();
float maior(float a1, float a2, float a3, float a4);
float menor(float a1, float a2, float a3, float a4);

#endif
