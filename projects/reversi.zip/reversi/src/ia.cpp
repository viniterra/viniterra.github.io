#include "ia.h"


int matrizPesos[8][8] = {{64,-8,8,8,8,8,-8,64},
			 {-8,-8,1,1,1,1,-8,-8},
			 {8,1,1,1,1,1,1,8},
			 {8,1,1,1,1,1,1,8},
			 {8,1,1,1,1,1,1,8},
			 {8,1,1,1,1,1,1,8},
			 {-8,-8,1,1,1,1,-8,-8},
			 {64,-8,8,8,8,8,-8,64}};

void calculaJogadasPossiveis(int tabuleiroPai[8][8], nodo_t * nodoPai, int nivelCorte, int nivelRaiz, int cor) {
	 
    bool jogadasPossiveis[8][8];
	int i = 0; int j = 0;
	int vizinho_i;
	int vizinho_j;
	bool casaPode;
	
	// se for um ex nodo folha
	if(nodoPai->num_filhos == 0){
    
    	for (i=0; i<8; i++) {  
    		for (j=0; j<8; j++) {
    			//zera a casa
    		       	jogadasPossiveis[i][j] = false;
    		       	casaPode = false;
    			//se a possivel jogada esta vazia
    			if(tabuleiroPai[i][j] == VAZIA) {		
    				//Vizinhos:
    				//|2|3|4| 
    				//|1|o|5| 
    				//|8|7|6| 
    
    				//verifica vizinho 1
    				vizinho_i = i;
    				vizinho_j = j - 1;	
    				//confere se a casa esta dentro do tabuleiro
    				if (vizinho_i >= 0 && vizinho_i < 8 && vizinho_j >= 0 && vizinho_j < 8) {
    					//se o vizinho for de cor diferente
    					if (tabuleiroPai[vizinho_i][vizinho_j] == !cor)	{
    						//enquanto nao chegar na borda verifica o vizinho ao lado
    						while (vizinho_j > 0) {
    							vizinho_j--;
    							if (tabuleiroPai[vizinho_i][vizinho_j] == cor)	{
    								jogadasPossiveis[i][j] = true;
    								// achou uma jogada possivel
    								nodo_t * filho;
    								if(cor==BRANCA){
            								filho = criaNodo(nodoPai,PIOR_DIF,i,j);//filho eh MAX
				                                }
    								else{
    								    filho = criaNodo(nodoPai,MELHOR_DIF,i,j); // filho eh MIN
                                    				}
    								insereFilho(nodoPai,filho);
    								casaPode = true;
									break;					    
    
    							} else if (tabuleiroPai[vizinho_i][vizinho_j] == VAZIA) {
    								break;
    							}	
    						}		
    					}	
    				}
    				
    				if(casaPode)
						continue;
    				
    				//verifica vizinho 2
    				vizinho_i = i - 1;
    				vizinho_j = j - 1;	
    				//confere se a casa esta dentro do tabuleiro
    				if (vizinho_i >= 0 && vizinho_i < 8 && vizinho_j >= 0 && vizinho_j < 8) {
    					//se o vizinho for de cor diferente
    					if (tabuleiroPai[vizinho_i][vizinho_j] == !cor)	{
    						//enquanto nao chegar na borda verifica o vizinho ao lado
    						while (vizinho_i > 0 && vizinho_j > 0) {
    							vizinho_i--; vizinho_j--; 
    							if (tabuleiroPai[vizinho_i][vizinho_j] == cor)	{
    								jogadasPossiveis[i][j] = true;
    								// achou uma jogada possivel
    								nodo_t * filho;
    								if(cor==BRANCA){
            								filho = criaNodo(nodoPai,PIOR_DIF,i,j);//filho eh MAX
				                                }
    								else{
    								    filho = criaNodo(nodoPai,MELHOR_DIF,i,j); // filho eh MIN
                                    				}

    								insereFilho(nodoPai,filho);
    								casaPode = true;    								
    								break;
    
    							} else if (tabuleiroPai[vizinho_i][vizinho_j] == VAZIA) {
    								break;
    							}	
    						}		
    					}	
    				}
    				
    				if(casaPode)
						continue;
    				
    				//verifica vizinho 3
    				vizinho_i = i - 1;
    				vizinho_j = j;	
    				//confere se a casa esta dentro do tabuleiro
    				if (vizinho_i >= 0 && vizinho_i < 8 && vizinho_j >= 0 && vizinho_j < 8) {
    					//se o vizinho for de cor diferente
    					if (tabuleiroPai[vizinho_i][vizinho_j] == !cor)	{
    						//enquanto nao chegar na borda verifica o vizinho ao lado
    						while (vizinho_i > 0) {
    							vizinho_i--;
    							if (tabuleiroPai[vizinho_i][vizinho_j] == cor)	{
    								jogadasPossiveis[i][j] = true;
    								// achou uma jogada possivel
    								nodo_t * filho;
    								if(cor==BRANCA){
            								filho = criaNodo(nodoPai,PIOR_DIF,i,j);//filho eh MAX
				                                }
    								else{
    								    filho = criaNodo(nodoPai,MELHOR_DIF,i,j); // filho eh MIN
                                    				}
    								insereFilho(nodoPai,filho);
    								casaPode = true;
									break;	
    
    							} else if (tabuleiroPai[vizinho_i][vizinho_j] == VAZIA) {
    								break;
    							}	
    						}		
    					}	
    				}
    				
    				if(casaPode)
						continue;
    				
    				//verifica vizinho 4
    				vizinho_i = i - 1;
    				vizinho_j = j + 1;	
    				//confere se a casa esta dentro do tabuleiro
    				if (vizinho_i >= 0 && vizinho_i < 8 && vizinho_j >= 0 && vizinho_j < 8) {
    					//se o vizinho for de cor diferente
    					if (tabuleiroPai[vizinho_i][vizinho_j] == !cor)	{
    						//enquanto nao chegar na borda verifica o vizinho ao lado
    						while (vizinho_i > 0 && vizinho_j < 7) {
    							vizinho_i--; vizinho_j++; 
    							if (tabuleiroPai[vizinho_i][vizinho_j] == cor)	{
    								jogadasPossiveis[i][j] = true;
    								// achou uma jogada possivel
    								nodo_t * filho;
    								if(cor==BRANCA){
            								filho = criaNodo(nodoPai,PIOR_DIF,i,j);//filho eh MAX
				                                }
    								else{
    								    filho = criaNodo(nodoPai,MELHOR_DIF,i,j); // filho eh MIN
                                    				}

    								insereFilho(nodoPai,filho);
    								casaPode = true;
									break;
    								
    							} else if (tabuleiroPai[vizinho_i][vizinho_j] == VAZIA) {
    								break;
    							}	
    						}		
    					}	
    				}
    				
    				if(casaPode)
						continue;
    				
    				//verifica vizinho 5
    				vizinho_i = i;
    				vizinho_j = j + 1;	
    				//confere se a casa esta dentro do tabuleiro
    				if (vizinho_i >= 0 && vizinho_i < 8 && vizinho_j >= 0 && vizinho_j < 8) {
    					//se o vizinho for de cor diferente
    					if (tabuleiroPai[vizinho_i][vizinho_j] == !cor)	{
    						//enquanto nao chegar na borda verifica o vizinho ao lado
    						while (vizinho_j < 7) {
    							vizinho_j++;
    							if (tabuleiroPai[vizinho_i][vizinho_j] == cor)	{
    								jogadasPossiveis[i][j] = true;
    								// achou uma jogada possivel
    								nodo_t * filho;
    								if(cor==BRANCA){
            								filho = criaNodo(nodoPai,PIOR_DIF,i,j);//filho eh MAX
				                                }
    								else{
    								    filho = criaNodo(nodoPai,MELHOR_DIF,i,j); // filho eh MIN
                                    				}
    								insereFilho(nodoPai,filho);
    								casaPode = true;
									break;	
    
    							} else if (tabuleiroPai[vizinho_i][vizinho_j] == VAZIA) {
    								break;
    							}	
    						}		
    					}	
    				}
    				
    				if(casaPode)
						continue;
    				
    				//verifica vizinho 6
    				vizinho_i = i + 1;
    				vizinho_j = j + 1;	
    				//confere se a casa esta dentro do tabuleiro
    				if (vizinho_i >= 0 && vizinho_i < 8 && vizinho_j >= 0 && vizinho_j < 8) {
    					//se o vizinho for de cor diferente
    					if (tabuleiroPai[vizinho_i][vizinho_j] == !cor)	{
    						//enquanto nao chegar na borda verifica o vizinho ao lado
    						while (vizinho_i < 7 && vizinho_j < 7) {
    							vizinho_i++; vizinho_j++; 
    							if (tabuleiroPai[vizinho_i][vizinho_j] == cor)	{
    								jogadasPossiveis[i][j] = true;
    								// achou uma jogada possivel
    								nodo_t * filho;
    								if(cor==BRANCA){
            								filho = criaNodo(nodoPai,PIOR_DIF,i,j);//filho eh MAX
				                                }
    								else{
    								    filho = criaNodo(nodoPai,MELHOR_DIF,i,j); // filho eh MIN
                                    				}
    								insereFilho(nodoPai,filho);
    								casaPode = true;
									break;	
    								
    							} else if (tabuleiroPai[vizinho_i][vizinho_j] == VAZIA) {
    								break;
    							}	
    						}		
    					}	
    				}
    				
    				if(casaPode)
						continue;
    				
    				//verifica vizinho 7
    				vizinho_i = i + 1;
    				vizinho_j = j;	
    				//confere se a casa esta dentro do tabuleiro
    				if (vizinho_i >= 0 && vizinho_i < 8 && vizinho_j >= 0 && vizinho_j < 8) {
    					//se o vizinho for de cor diferente
    					if (tabuleiroPai[vizinho_i][vizinho_j] == !cor)	{
    						//enquanto nao chegar na borda verifica o vizinho ao lado
    						while (vizinho_i < 7) {
    							vizinho_i++;
    							if (tabuleiroPai[vizinho_i][vizinho_j] == cor)	{
    								jogadasPossiveis[i][j] = true;
    								// achou uma jogada possivel
    								nodo_t * filho;
    								if(cor==BRANCA){
            								filho = criaNodo(nodoPai,PIOR_DIF,i,j);//filho eh MAX
				                                }
    								else{
    								    filho = criaNodo(nodoPai,MELHOR_DIF,i,j); // filho eh MIN
                                    				}

    								insereFilho(nodoPai,filho);
    								casaPode = true;
									break;	
    
    							} else if (tabuleiroPai[vizinho_i][vizinho_j] == VAZIA) {
    								break;
    							}	
    						}		
    					}	
    				}
    				
    				if(casaPode)
						continue;
    				
    				//verifica vizinho 8
    				vizinho_i = i + 1;
    				vizinho_j = j - 1;	
    				//confere se a casa esta dentro do tabuleiro
    				if (vizinho_i >= 0 && vizinho_i < 8 && vizinho_j >= 0 && vizinho_j < 8) {
    					//se o vizinho for de cor diferente
    					if (tabuleiroPai[vizinho_i][vizinho_j] == !cor)	{
    						//enquanto nao chegar na borda verifica o vizinho ao lado
    						while (vizinho_i < 7 && vizinho_j > 0) {
    							vizinho_i++; vizinho_j--; 
    							if (tabuleiroPai[vizinho_i][vizinho_j] == cor)	{
    								jogadasPossiveis[i][j] = true;
    								// achou uma jogada possivel
    								nodo_t * filho;
    								if(cor==BRANCA){
            								filho = criaNodo(nodoPai,PIOR_DIF,i,j);//filho eh MAX
				                                }
    								else{
    								    filho = criaNodo(nodoPai,MELHOR_DIF,i,j); // filho eh MIN
                                    				}
    								insereFilho(nodoPai,filho);
									break;	
    
    							} else if (tabuleiroPai[vizinho_i][vizinho_j] == VAZIA) {
    								break;
    							}	
    						}		
    					}	
    				}
    			}	
    		}	
    	}
    }
	
//para cada filho na lista
    nodo_t * itera = nodoPai->filhos->inicio;
    nodoPai->alfabeta = itera;
    while(itera != NULL){ // enquanto nao for ultimo da fila
   	
	    
        // cria o tabuleiro do filho						
        simulaJogada(tabuleiroPai, itera, cor, itera->casa_i, itera->casa_j);

        //	se filho for nodo folha (nivel maximo atingido)
        if(itera->nivel == nivelCorte){
        //atribui peso (preta-branca ou vice e versa)
		itera->valor = utilidade(itera->tabuleiro);
        }
        else{ //	se filho nao for nodo folha
        //	chama a funcao para calcular cada jogada pro filho
                calculaJogadasPossiveis(itera->tabuleiro, itera, nivelCorte, nivelRaiz, !cor);
        }
        
//	se peso retornado for maior (max) ou menor(min), corrente = retornado
        if(cor==BRANCA){ // vez de MAX
           if(nodoPai->valor < itera->valor){
                nodoPai->valor = itera->valor;
                nodoPai->alfabeta = itera;
           }

	    if (nodoPai->pai != NULL && nodoPai->pai->alfabeta != NULL) {
		//poda alfa beta
		#ifdef LINUX 
	       if (itera->valor > nodoPai->pai->alfabeta->valor) {
			break;
	       }	
	   	#endif 
	   }
	   
        }
        else{ // vez de min
           if(nodoPai->valor > itera->valor){
                nodoPai->valor = itera->valor;
                nodoPai->alfabeta = itera;
           } 
		   if (nodoPai->pai != NULL && nodoPai->pai->alfabeta != NULL) {
			//poda alfa beta
			#ifdef LINUX 
		       if (itera->valor < nodoPai->pai->alfabeta->valor) {
				break;
		       }
			#endif 
		   }
    	}


        itera = itera->ant;
    }

//fim para cada filho	
	
}

bool simulaTroca( int * casa){ // simula troca de peca existente na casa para outra cor
    if(*casa == PRETA){
        *casa = BRANCA;
        return true;
    }
    else if(*casa == BRANCA){
        *casa = PRETA;
        return true;
    }
    return false;
}

void contaPecas(nodo_t *nodo){
     nodo->pretas = 0; nodo->brancas = 0;
     for(int i=0;i<8;i++){
          for(int j=0;j<8;j++){
                  if(nodo->tabuleiro[i][j] == PRETA)
                       nodo->pretas++;
                  else if(nodo->tabuleiro[i][j] == BRANCA)
                       nodo->brancas++;
          }
     }
}

void simulaJogada(int tabuleiro[8][8], nodo_t *nodo, unsigned int cor, int casa_i, int casa_j) {

	int vizinho_i,vizinho_j, i, j;
	
	//copia tabuleiro do pai
	
	for(i=0; i<8; i++) {
		for(j=0; j<8; j++){
			nodo->tabuleiro[i][j] = tabuleiro[i][j]; 
		}	
	}	
		
	//verifica vizinho 1
	vizinho_i = casa_i;
	vizinho_j = casa_j - 1;	
	//confere se a casa esta dentro do tabuleiro
	if (vizinho_i >= 0 && vizinho_i < 8 && vizinho_j >= 0 && vizinho_j < 8) {
		//se o vizinho for de cor diferente
		if (tabuleiro[vizinho_i][vizinho_j] == !cor)	{
			//enquanto nao chegar na borda verifica o vizinho ao lado
			while (vizinho_j > 0) {
				vizinho_j--;
				// achou o vizinho de mesma cor
				if (tabuleiro[vizinho_i][vizinho_j] == (int) cor)	{
					// volta trocando a cor das pecas
					while(vizinho_j < casa_j-1){
						vizinho_j++;
						simulaTroca(&(nodo->tabuleiro[vizinho_i][vizinho_j]));
					}
					break;
				} else if (tabuleiro[vizinho_i][vizinho_j] == VAZIA) {
					break;
				}	
			}		
		}	
	}
	//verifica vizinho 2
	vizinho_i = casa_i - 1;
	vizinho_j = casa_j - 1;	
	//confere se a casa esta dentro do tabuleiro
	if (vizinho_i >= 0 && vizinho_i < 8 && vizinho_j >= 0 && vizinho_j < 8) {
		//se o vizinho for de cor diferente
		if (tabuleiro[vizinho_i][vizinho_j] == !cor)	{
			//enquanto nao chegar na borda verifica o vizinho ao lado
			while (vizinho_i > 0 && vizinho_j > 0) {
				vizinho_i--; vizinho_j--; 
				// achou vizinho da mesma cor
				if (tabuleiro[vizinho_i][vizinho_j] ==(int) cor)	{
					// volta trocando a cor das pecas
					while(vizinho_i < casa_i-1 && vizinho_j < casa_j-1){
						vizinho_i++; vizinho_j++;
						simulaTroca(&nodo->tabuleiro[vizinho_i][vizinho_j]);
					}
					break;
				} else if (tabuleiro[vizinho_i][vizinho_j] == VAZIA) {
					break;
				}	
			}		
		}	
	}
	//verifica vizinho 3
	vizinho_i = casa_i - 1;
	vizinho_j = casa_j;	
	//confere se a casa esta dentro do tabuleiro
	if (vizinho_i >= 0 && vizinho_i < 8 && vizinho_j >= 0 && vizinho_j < 8) {
		//se o vizinho for de cor diferente
		if (tabuleiro[vizinho_i][vizinho_j] == !cor)	{
			//enquanto nao chegar na borda verifica o vizinho ao lado
			while (vizinho_i > 0) {
				vizinho_i--;
				if (tabuleiro[vizinho_i][vizinho_j] ==(int) cor)	{
					// volta trocando a cor das pecas
					while(vizinho_i < casa_i-1){
						vizinho_i++;
						simulaTroca(&(nodo->tabuleiro[vizinho_i][vizinho_j]));
					}
					break;
				} else if (tabuleiro[vizinho_i][vizinho_j] == VAZIA) {
					break;
				}	
			}		
		}	
	}
	//verifica vizinho 4
	vizinho_i = casa_i - 1;
	vizinho_j = casa_j + 1;	
	//confere se a casa esta dentro do tabuleiro
	if (vizinho_i >= 0 && vizinho_i < 8 && vizinho_j >= 0 && vizinho_j < 8) {
		//se o vizinho for de cor diferente
		if (tabuleiro[vizinho_i][vizinho_j] == !cor)	{
			//enquanto nao chegar na borda verifica o vizinho ao lado
			while (vizinho_i > 0 && vizinho_j < 7) {
				vizinho_i--; vizinho_j++; 
				if (tabuleiro[vizinho_i][vizinho_j] ==(int) cor)	{
					// volta trocando a cor das pecas
					while(vizinho_i < casa_i-1 && vizinho_j > casa_j+1){
						vizinho_i++; vizinho_j--;
						simulaTroca(&(nodo->tabuleiro[vizinho_i][vizinho_j]));
					}
					break;
				} else if (tabuleiro[vizinho_i][vizinho_j] == VAZIA) {
					break;
				}	
			}		
		}	
	}
	//verifica vizinho 5
	vizinho_i = casa_i;
	vizinho_j = casa_j + 1;	
	//confere se a casa esta dentro do tabuleiro
	if (vizinho_i >= 0 && vizinho_i < 8 && vizinho_j >= 0 && vizinho_j < 8) {
		//se o vizinho for de cor diferente
		if (tabuleiro[vizinho_i][vizinho_j] == !cor)	{
			//enquanto nao chegar na borda verifica o vizinho ao lado
			while (vizinho_j < 7) {
				vizinho_j++;
				if (tabuleiro[vizinho_i][vizinho_j] ==(int) cor)	{
					while(vizinho_j > casa_j+1){
						vizinho_j--;
						simulaTroca(&(nodo->tabuleiro[vizinho_i][vizinho_j]));
					}
					break;
				} else if (tabuleiro[vizinho_i][vizinho_j] == VAZIA) {
					break;
				}	
			}		
		}	
	}
	//verifica vizinho 6
	vizinho_i = casa_i + 1;
	vizinho_j = casa_j + 1;	
	//confere se a casa esta dentro do tabuleiro
	if (vizinho_i >= 0 && vizinho_i < 8 && vizinho_j >= 0 && vizinho_j < 8) {
		//se o vizinho for de cor diferente
		if (tabuleiro[vizinho_i][vizinho_j] == !cor)	{
			//enquanto nao chegar na borda verifica o vizinho ao lado
			while (vizinho_i < 7 && vizinho_j < 7) {
				vizinho_i++; vizinho_j++; 
				if (tabuleiro[vizinho_i][vizinho_j] ==(int) cor)	{
					while(vizinho_i > casa_i+1 && vizinho_j > casa_j+1){
						vizinho_i--; vizinho_j--;
						simulaTroca(&(nodo->tabuleiro[vizinho_i][vizinho_j]));
					}
					break;
				} else if (tabuleiro[vizinho_i][vizinho_j] == VAZIA) {
					break;
				}	
			}		
		}	
	}
	//verifica vizinho 7
	vizinho_i = casa_i + 1;
	vizinho_j = casa_j;	
	//confere se a casa esta dentro do tabuleiro
	if (vizinho_i >= 0 && vizinho_i < 8 && vizinho_j >= 0 && vizinho_j < 8) {
		//se o vizinho for de cor diferente
		if (tabuleiro[vizinho_i][vizinho_j] == !cor)	{
			//enquanto nao chegar na borda verifica o vizinho ao lado
			while (vizinho_i < 7) {
				vizinho_i++;
				if (tabuleiro[vizinho_i][vizinho_j] ==(int) cor)	{
					while(vizinho_i > casa_i+1){
						vizinho_i--;
						simulaTroca(&(nodo->tabuleiro[vizinho_i][vizinho_j]));
					}
					break;
				} else if (tabuleiro[vizinho_i][vizinho_j] == VAZIA) {
					break;
				}	
			}		
		}	
	}
	//verifica vizinho 8
	vizinho_i = casa_i + 1;
	vizinho_j = casa_j - 1;	
	//confere se a casa esta dentro do tabuleiro
	if (vizinho_i >= 0 && vizinho_i < 8 && vizinho_j >= 0 && vizinho_j < 8) {
		//se o vizinho for de cor diferente
		if (tabuleiro[vizinho_i][vizinho_j] == !cor)	{
			//enquanto nao chegar na borda verifica o vizinho ao lado
			while (vizinho_i < 7 && vizinho_j > 0) {
				vizinho_i++; vizinho_j--; 
				if (tabuleiro[vizinho_i][vizinho_j] ==(int) cor)	{
					// volta trocando a cor das pecas
					while(vizinho_i > casa_i+1 && vizinho_j < casa_j-1){
						vizinho_i--; vizinho_j++;
						simulaTroca(&(nodo->tabuleiro[vizinho_i][vizinho_j]));
					}
					break;
				} else if (tabuleiro[vizinho_i][vizinho_j] == VAZIA) {
					break;
				}	
			}		
		}	
	}
	
	//coloca a posicao da jogada com a cor
	nodo->tabuleiro[casa_i][casa_j] = cor;
	
	contaPecas(nodo);

}

int utilidade(int tabuleiro[8][8]){
	int peso = 0;
	for(int i=0;i<8;i++){
		for(int j=0;j<8;j++){
			if(tabuleiro[i][j]==BRANCA)
				peso += matrizPesos[i][j];
			else if(tabuleiro[i][j]==PRETA)
				peso -= matrizPesos[i][j];
		}
	}
	return peso;
}

