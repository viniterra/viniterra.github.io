#ifndef _lista_h
#define _lista_h

#include <stdlib.h>
#include "arvore.h"

typedef struct lista_t{
        nodo_t* inicio;
        nodo_t* fim;
        int numNodos;
} lista_t;


void iniciaLista(lista_t *lista);
void adicionaLista(lista_t *lista, nodo_t * novo_nodo);
//void retiraLista(lista_t *lista, nodo_t * nodo);

#endif
