====================================================
Boids & Flocking Simulation
====================================================
Author: Vinicius Marques Terra
====================================================

    
Introduction
------------------------

This is a demo featuring Boids, an artificial life simulation for flocking behavior of birds.
Based on emergent behavior, the complexity of Boids arises from the interaction of individual
agents adhering to a set of simple rules. The basic rules applied are as follows:

- Separation: steer to avoid crowding local flockmates.
- Alignment: steer towards the average heading of local flockmates.
- Cohesion: steer to move toward the average position (center of mass) of localflockmates.

This demo also implements obstacle avoidance, goal seeking, and three different camera views.


Controls
------------------------

Mouse axis : main boid movement
Key 1 : tower camera (track on main boid)
Key 2 : third person camera - back view
Key 3 : third person camera - side view
Key a : increase camera zoom (third person cameras only)
Key z : decrease camera zoom (third person cameras only)
Key + : increase number of boids (max 20)
Key - : decrease number of boids (min 0)
ESC Key : exit simulation
