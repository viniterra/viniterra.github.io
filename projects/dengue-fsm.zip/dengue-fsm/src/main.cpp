#include<GL/glut.h>
#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#ifdef _WIN32
#include <windows.h>
#endif

#include "tga.h"
#include "agente.h"
#include "vetor.h"
#include "functions.h"
#include "mosquito.h"
#include "poca.h"

#include <iostream>
#include <cstdarg>


#define PAUSE 0
#define RUN 1

#define PARADO 0.016

#ifdef _WIN32
//function pointer typdefs
typedef void (APIENTRY *PFNWGLEXTSWAPCONTROLPROC) (int);
typedef int (*PFNWGLEXTGETSWAPINTERVALPROC) (void);

//declare functions
PFNWGLEXTSWAPCONTROLPROC wglSwapIntervalEXT = NULL;
PFNWGLEXTGETSWAPINTERVALPROC wglGetSwapIntervalEXT = NULL;
#endif

short modo;
bool GAME_OVER;
bool VITORIA;

enum {
    BUTTON_LEFT = 0,
    BUTTON_RIGHT,
    BUTTON_LEFT_TRANSLATE,
};

// coordenadas do goal
float goalX, goalY;
float rotGoal;

// variaveis
int mButton = -1;
float width,height;

bool usaSpray = false; // esta usando spray

// lista de agentes
lista_agentes * agentes = NULL;

//lista de mosquito
lista_mosquitos * mosquitos = NULL;

//lista de poças
lista_pocas * pocas = NULL;

int i,j;
GLuint texturas[26]; // arranjo com texturas para desenhar

// frame rate
int fps = 0;
int frame=0,tempo,tempoBase=0;

// status dos agentes
bool animados;
float vel; // velocidade dos agentes

void calcularFPS(){
    frame++;
    tempo = glutGet(GLUT_ELAPSED_TIME);

    if (tempo - tempoBase > 1000) {
        fps = (int) frame*1000/(tempo-tempoBase);
        tempoBase = tempo;
        frame = 0;
    }
}

//funcao pra redimensionar a janela (redimensionamento travado)
void changeSize(int w, int h)
{

    if(h!=640 && w!=640)
        glutReshapeWindow(640,640);
    width = w;
    height = h;
    float ratio = 1.0* w / h;
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    glViewport(0, 0, w, h);
    gluPerspective(45,ratio,1,1000);
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
    gluLookAt(0.0,0.0,5.0,
              0.0,0.0,-1.0,
              0.0f,1.0f,0.0f);
}

void animaAgentes(){
    agente_t * itera = agentes->inicio;
    while(itera != NULL){
        itera->frame+=(12/(float)fps); // anda frame agente
        if(itera->frame >=11)
            itera->frame -=10;
        itera = itera->ant;
    }
    // anima goal
    rotGoal += 230/(float)fps;
    if(rotGoal > 359)
	    rotGoal -= 359;
}

void animaMosquitos(){
    mosquito_t * itera = mosquitos->inicio;
    while(itera != NULL){
        itera->frame+=(12/(float)fps); // anda frame mosquito
        if(itera->frame >=2)
            itera->frame -= 2;
        itera = itera->ant;
    }
}

void desenhaAreaRecarga(){
    // desenha hospital
    glPushMatrix();
        glBindTexture(GL_TEXTURE_2D, texturas[15]);
        glTranslatef(-1.87,-1.87,0.0);
        glBegin(GL_QUADS);
            glNormal3f( 0.0f, 0.0f, 1.0f);
            glTexCoord2f(0.0f, 0.0f);glVertex3f(-0.2f, -0.2f,  0.0f);
            glTexCoord2f(1.0f, 0.0f);glVertex3f( 0.2f, -0.2f,  0.0f);
            glTexCoord2f(1.0f, 1.0f);glVertex3f( 0.2f,  0.2f,  0.0f);
            glTexCoord2f(0.0f, 1.0f);glVertex3f(-0.2f,  0.2f,  0.0f);
        glEnd();
    glPopMatrix();

    // desenha municao
    glPushMatrix();
        glBindTexture(GL_TEXTURE_2D, texturas[16]);
        glTranslatef(-1.47,-1.87,0.0);
        glBegin(GL_QUADS);
            glNormal3f( 0.0f, 0.0f, 1.0f);
            glTexCoord2f(0.0f, 0.0f);glVertex3f(-0.2f, -0.2f,  0.0f);
            glTexCoord2f(1.0f, 0.0f);glVertex3f( 0.2f, -0.2f,  0.0f);
            glTexCoord2f(1.0f, 1.0f);glVertex3f( 0.2f,  0.2f,  0.0f);
            glTexCoord2f(0.0f, 1.0f);glVertex3f(-0.2f,  0.2f,  0.0f);
        glEnd();
    glPopMatrix();
}



// funcao de movimentacao: atualiza posicao dos agentes
void caminhaAgentes(){
	vel = 1.5/(float)fps;
	// para cada agente
	agente_t * itera = agentes->inicio;
	float A = 0.01;
	float B = 0.0000001;
	float m = 4;
	float n = 1.5;
	while(itera != NULL){
		// faz agente ir ate goal
		vetor2d * posicao = novoVetor(itera->posX, itera->posY);
		vetor2d * goal = novoVetor(itera->goalX, itera->goalY);
		vetor2d * caminhar = calculaVetor(posicao, goal); // vetor que define a distancia do agente para o goal
		float r = norma(caminhar);
		float atr = A* pow(r,n); // r^2
//	       	float rep = r- (B * m/pow(r,m)); // - 4/r^4
		normalizaVetor(caminhar);
		multiplicaEscalar(caminhar, atr);

		// para cada outro agente vizinho
		agente_t * vizinho = agentes->inicio;
		while(vizinho != NULL){
			if(vizinho != itera){ // nao e o proprio agente
				vetor2d * posVizinho = novoVetor(vizinho->posX, vizinho->posY); // posicao do vizinho
				vetor2d * distVizinho = calculaVetor(posVizinho,posicao); // sai do vizinho aponta pro agente
				float rVizinho = norma(distVizinho);
				float rep = B * m/pow(rVizinho,m);
				normalizaVetor(distVizinho);
				multiplicaEscalar(distVizinho,rep);

				caminhar = somaVetor(caminhar,distVizinho); // soma a repulsao para este vizinho

				freeVetor(posVizinho);
				freeVetor(distVizinho);
			}
			vizinho = vizinho->ant;
		}

		// para cada poca
		poca_t * poca = pocas->inicio;
		while(poca != NULL){
			vetor2d * posPoca = novoVetor(poca->posX, poca->posY); // posicao da poca
			vetor2d * distPoca = calculaVetor(posPoca,posicao); // sai da poca aponta pro agente
			float rPoca = norma(distPoca);
			float rep = B * m/pow(rPoca,m); // rever repulsao
			normalizaVetor(distPoca);
			multiplicaEscalar(distPoca,rep);

			caminhar = somaVetor(caminhar,distPoca); // soma a repulsao para este poca

			freeVetor(posPoca);
			freeVetor(distPoca);
			poca = poca->ant;
		}

		float velocidade = norma(caminhar);

		if(velocidade > vel){ // verifica se velocidade nao ultrapassa velocidade maxima
			normalizaVetor(caminhar);
			multiplicaEscalar(caminhar,vel);
		}
		if(velocidade < PARADO / (float)fps)
			itera->andando = false;
		else
			itera->andando = true;

		polar * pol = cart2pol(caminhar);

		itera-> ang = pol->thet + 90;

		itera->posX += caminhar->x; // soma delta a posicao do agente
		itera->posY += caminhar->y;

		freeVetor(posicao);
		freeVetor(goal);
		freeVetor(caminhar);

		itera = itera->ant;
	}
}

void desenhaLife(float life){
	if(life < 0){ // game over
		life = 0;
		GAME_OVER = true;
	}
	life = (life/50.0)-1.0;
	glPushMatrix();
	    glBindTexture(GL_TEXTURE_2D, texturas[20]);
	    glTranslatef(2.0,1.0,0.0);
	    glBegin(GL_QUADS);
	        glNormal3f( 0.0f, 0.0f, 1.0f);
	        glTexCoord2f(0.0f, 0.0f);glVertex3f(-0.02f, -1.0f,  0.0f);
        	glTexCoord2f(1.0f, 0.0f);glVertex3f( 0.02f, -1.0f,  0.0f);
	        glTexCoord2f(1.0f, 1.0f);glVertex3f( 0.02f,  life,  0.0f);
	        glTexCoord2f(0.0f, 1.0f);glVertex3f(-0.02f,  life,  0.0f);
	    glEnd();
	glPopMatrix();
}

void desenhaSpray(float spray, agente_t * player){
	if(spray < 0){
		spray = 0;
		usaSpray = false;
	}
	spray = (spray/50.0)-1.0;
	// barra de quantidade de spray
	glPushMatrix();
	    glBindTexture(GL_TEXTURE_2D, texturas[23]);
	    glTranslatef(1.9,1.0,0.0);
	    glBegin(GL_QUADS);
	        glNormal3f( 0.0f, 0.0f, 1.0f);
	        glTexCoord2f(0.0f, 0.0f);glVertex3f(-0.02f, -1.0f,  0.0f);
        	glTexCoord2f(1.0f, 0.0f);glVertex3f( 0.02f, -1.0f,  0.0f);
	        glTexCoord2f(1.0f, 1.0f);glVertex3f( 0.02f,  spray,  0.0f);
	        glTexCoord2f(0.0f, 1.0f);glVertex3f(-0.02f,  spray,  0.0f);
	    glEnd();
	glPopMatrix();

	if(usaSpray){
		// spray ao redor do agente
		glPushMatrix();
			glBindTexture(GL_TEXTURE_2D, texturas[13]);
			glTranslatef(player->posX,player->posY,0.0);
			glRotatef(rotGoal*2,0.0,0.0,1.0);
			glBegin(GL_QUADS);
				glNormal3f( 0.0f, 0.0f, 1.0f);
				glTexCoord2f(0.0f, 0.0f);glVertex3f(-0.2f, -0.2f,  0.0f);
				glTexCoord2f(1.0f, 0.0f);glVertex3f( 0.2f, -0.2f,  0.0f);
				glTexCoord2f(1.0f, 1.0f);glVertex3f( 0.2f,  0.2,  0.0f);
				glTexCoord2f(0.0f, 1.0f);glVertex3f(-0.2f,  0.2,  0.0f);
			glEnd();
		glPopMatrix();
	}

}

void mataMosquitos(agente_t * player, lista_mosquitos * mosquitos){

	mosquito_t * iteraMosq = mosquitos->inicio;
	vetor2d	 * posPlayer = novoVetor(player->posX, player->posY);
	vetor2d * posMosq;

	while(iteraMosq != NULL){
		// calcula se mosquito esta no raio do spray
		posMosq = novoVetor(iteraMosq->posX, iteraMosq->posY);
		float distancia = norma(calculaVetor(posPlayer,posMosq));
		if(distancia <= 0.2){ // mosquito esta dentro do raio do spray
			iteraMosq->life -= 400/(float)fps; // tira life do mosquito
		}
		if(iteraMosq->life <= 0.0){
			removeMosquito(mosquitos, iteraMosq); // mosquito morto
			if(mosquitos->numMosquitos == 0){
				VITORIA = true;
			}
		}
		iteraMosq = iteraMosq->ant;
		freeVetor(posMosq);
	}
	freeVetor(posPlayer);
}

void verificaRecarga(agente_t * player){
	// verifica se esta nas zonas de recarga
	if(player->posY >=-2.0 && player->posY<=-1.62 ){
//		printf("entrou Y\n");
		// verifica se esta na zona hospital
			if(player->posX >= -2.0 && player->posX <= -1.61){
//			printf("entrou X hosp\n");
			// aumenta life
			player->life += 20/(float)fps;
			if(player->life >100)
				player->life = 100;
		}
		// verifica se esta n a zona de municao
		if(player->posX >= -1.61 && player->posX <= -1.22 ){
			// aumenta municao
//			printf("entrou X municao\n");
			player->spray += 20/(float)fps;
			if(player->spray >100)
				player->spray = 100;
		}
	}
}

// funcao pra desenhar os sprites na tela
void renderScene(void)
{

    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

    //  desenha backgound
    glBindTexture(GL_TEXTURE_2D, texturas[11+ (10*(int)!animados)]);
    glBegin(GL_QUADS);
        glNormal3f( 0.0f, 0.0f, 1.0f);
        glTexCoord2f(0.0f, 0.0f);glVertex3f(-3.0f, -3.0f,  -2.0f);
        glTexCoord2f(10.0f, 0.0f);glVertex3f( 3.0f, -3.0f,  -2.0f);
        glTexCoord2f(10.0f, 10.0f);glVertex3f( 3.0f,  3.0f,  -2.0f);
        glTexCoord2f(0.0f, 10.0f);glVertex3f(-3.0f,  3.0f,  -2.0f);
    glEnd();

    //	desenha pocas
    poca_t * iteraPoc = pocas->inicio;
    while(iteraPoc != NULL){
        glPushMatrix();
            glBindTexture(GL_TEXTURE_2D, texturas[19]);
            glTranslatef(iteraPoc->posX,iteraPoc->posY,0.0);
            glBegin(GL_QUADS);
                glNormal3f( 0.0f, 0.0f, 1.0f);
                glTexCoord2f(0.0f, 0.0f);glVertex3f(-0.1f, -0.1f,  0.0f);
                glTexCoord2f(1.0f, 0.0f);glVertex3f( 0.1f, -0.1f,  0.0f);
                glTexCoord2f(1.0f, 1.0f);glVertex3f( 0.1f,  0.1f,  0.0f);
                glTexCoord2f(0.0f, 1.0f);glVertex3f(-0.1f,  0.1f,  0.0f);
            glEnd();
        glPopMatrix();
        iteraPoc = iteraPoc->ant;
    }

    // desenha zonas de recarga de life e municao
    desenhaAreaRecarga();

    // desenha goal
    glPushMatrix();
    glBindTexture(GL_TEXTURE_2D, texturas[18]);
    glTranslatef(goalX,goalY,0.0);
    glRotatef(rotGoal,0.0,0.0,1.0);
    glBegin(GL_QUADS);
        glNormal3f( 0.0f, 0.0f, 1.0f);
        glTexCoord2f(0.0f, 0.0f);glVertex3f(-0.1f, -0.1f,  0.0f);
        glTexCoord2f(1.0f, 0.0f);glVertex3f( 0.1f, -0.1f,  0.0f);
        glTexCoord2f(1.0f, 1.0f);glVertex3f( 0.1f,  0.1f,  0.0f);
        glTexCoord2f(0.0f, 1.0f);glVertex3f(-0.1f,  0.1f,  0.0f);
    glEnd();
    glPopMatrix();

    //  desenha jogador
    agente_t * itera = agentes->inicio;
    while(itera != NULL){
        //player
        glPushMatrix();
            glBindTexture(GL_TEXTURE_2D, texturas[(int)(itera->frame) * (int) animados * itera->andando]);
            glTranslatef(itera->posX,itera->posY,0.0);
            glRotatef(itera->ang, 0.0,0.0,1.0);
            glBegin(GL_QUADS);
                glNormal3f( 0.0f, 0.0f, 1.0f);
                glTexCoord2f(0.0f, 0.0f);glVertex3f(-0.06f, -0.1f,  0.0f);
                glTexCoord2f(0.99f, 0.0f);glVertex3f( 0.06f, -0.1f,  0.0f);
                glTexCoord2f(0.99f, 0.99f);glVertex3f( 0.06f,  0.1f,  0.0f);
                glTexCoord2f(0.0f, 0.99f);glVertex3f(-0.06f,  0.1f,  0.0f);
            glEnd();
        glPopMatrix();
        itera = itera->ant;
    }

    //  desenha mosquitos
    mosquito_t * iteraMosq = mosquitos->inicio;
    while(iteraMosq != NULL){
        //mosquito
        if(modo == RUN && !GAME_OVER)
	        handleFSM(iteraMosq,mosquitos,fps,&vel, agentes->inicio, pocas);
        glPushMatrix();
            glBindTexture(GL_TEXTURE_2D, texturas[24 + ((int)(iteraMosq->frame) * iteraMosq->andando)]);
            glTranslatef(iteraMosq->posX,iteraMosq->posY,0.0);
            glRotatef(iteraMosq->ang, 0.0,0.0,1.0);
            glBegin(GL_QUADS);
                glNormal3f( 0.0f, 0.0f, 1.0f);
                glTexCoord2f(0.0f, 0.0f);glVertex3f(-0.06f, -0.1f,  0.0f);
                glTexCoord2f(0.99f, 0.0f);glVertex3f( 0.06f, -0.1f,  0.0f);
                glTexCoord2f(0.99f, 0.99f);glVertex3f( 0.06f,  0.1f,  0.0f);
                glTexCoord2f(0.0f, 0.99f);glVertex3f(-0.06f,  0.1f,  0.0f);
            glEnd();
        glPopMatrix();
        iteraMosq = iteraMosq->ant;
    }

    // desenha termometro life
    desenhaLife(agentes->inicio->life);

    if(usaSpray && modo == RUN){
	agentes->inicio->spray -= 40.0/(float)fps;
	mataMosquitos(agentes->inicio, mosquitos);
    }

    desenhaSpray(agentes->inicio->spray,agentes->inicio);

    if(!GAME_OVER && !VITORIA){

	    if(modo == PAUSE){
	        animados = false;
	    }
	    else if(modo == RUN){
	        animados = true;
	        animaAgentes();
		caminhaAgentes();

		animaMosquitos();
		verificaRecarga(agentes->inicio);
	    }
    }
    else if(GAME_OVER){
	// desenhar tela game over
	glPushMatrix();
            glBindTexture(GL_TEXTURE_2D, texturas[12]);
            glBegin(GL_QUADS);
                glNormal3f( 0.0f, 0.0f, 1.0f);
                glTexCoord2f(0.0f, 0.0f);glVertex3f(-2.0f, -2.0f,  0.0f);
                glTexCoord2f(1.0f, 0.0f);glVertex3f( 2.0f, -2.0f,  0.0f);
                glTexCoord2f(1.0f, 1.0f);glVertex3f( 2.0f,  2.0f,  0.0f);
                glTexCoord2f(0.0f, 1.0f);glVertex3f(-2.0f,  2.0f,  0.0f);
            glEnd();
        glPopMatrix();

    }
    else if(VITORIA){
	// desenhar tela vitoria
	glPushMatrix();
            glBindTexture(GL_TEXTURE_2D, texturas[14]);
            glBegin(GL_QUADS);
                glNormal3f( 0.0f, 0.0f, 1.0f);
                glTexCoord2f(0.0f, 0.0f);glVertex3f(-2.0f, -2.0f,  0.0f);
                glTexCoord2f(1.0f, 0.0f);glVertex3f( 2.0f, -2.0f,  0.0f);
                glTexCoord2f(1.0f, 1.0f);glVertex3f( 2.0f,  2.0f,  0.0f);
                glTexCoord2f(0.0f, 1.0f);glVertex3f(-2.0f,  2.0f,  0.0f);
            glEnd();
        glPopMatrix();
    }

    calcularFPS();
    glutSwapBuffers();

}

/*void setaBotao(int x, int y){
    // Agente
    if(x >= 228 && x <= 288
    && y >= 580 && y <= 640)
        modo = PAUSE;

    // Goal
    if(x >= 350 && x <= 410
    && y >= 580 && y <= 640)
        modo = RUN;
}*/

void handleAgente(){
	agente_t * agente = criaAgente(0.01, 0.01, 0, 1, goalX, goalY);
	adicionaAgente(agentes,agente);
}



// funcao para processar os cliques do mouse
void processMouse(int button, int state, int x, int y)
{


    if(state == GLUT_DOWN)
    {
        switch(button)
        {
            case GLUT_LEFT_BUTTON: // apertou botao esquerdo
            mButton = BUTTON_LEFT;
            if(modo == RUN)
                glutSetCursor(GLUT_CURSOR_NONE);
            	if(modo == RUN){ // modo jogar
	    		goalX = ((float)x * 0.00625)-2; // X relativo
	       		goalY = (2-(float)y * 0.00625); // Y relativo
       			// para cada agente ativo setar o goal
		       agente_t * itera = agentes->inicio;
		       while(itera != NULL){
		            itera->goalX = goalX; // seta goal do agente
        		    itera->goalY = goalY;
	        	    itera = itera->ant;
       			}
		}

            break;

            case GLUT_RIGHT_BUTTON: // apertou botao direito
                mButton = BUTTON_RIGHT;
               	glutSetCursor(GLUT_CURSOR_SPRAY);
		usaSpray = true;
            break;

            case GLUT_MIDDLE_BUTTON: // apertou botao do meio
            break;
        }
    }
    else if (state == GLUT_UP)
    {
	usaSpray = false;
	glutSetCursor(GLUT_CURSOR_LEFT_ARROW);
    }

}

// funcoes para processar mouse em movimento (nao precisa)
void processMouseActiveMotion(int x, int y)
{
    	if(modo == RUN){ // modo jogar
		switch(mButton)
	        {
        	case BUTTON_LEFT:
		{
	    		goalX = ((float)x * 0.00625)-2; // X relativo
	       		goalY = (2-(float)y * 0.00625); // Y relativo
			// limites da tela
			if(goalX > 2.0)
				goalX = 2.0;
			if(goalY >2.0)
				goalY = 2.0;
			if(goalX < -2.0)
				goalX = -2.0;
			if(goalY < -2.0)
				goalY = -2.0;
			// para cada agente ativo setar o goal
		       	agente_t * itera = agentes->inicio;
		      	while(itera != NULL){
		            itera->goalX = goalX; // seta goal do agente
			    itera->goalY = goalY;
	        	    itera = itera->ant;
			}
		}
		break;

/*		case BUTTON_RIGHT:
			agentes->inicio->spray -= 100.0/(float)fps;
		break;*/
		}
	}
}
void processMousePassiveMotion(int x, int y)
{}

// funcao para reiniciar o jogo (lembrar de resetar novas variaveis)
void RESET()
{
    fps = 10;
    GAME_OVER = false; VITORIA = false;
    goalX = 0.0; goalY = 0.0;
    // se a lista de agentes nao for nula, o seu espaco de memoria deve ser liberado
    if (agentes != NULL) {
	agente_t * itera = agentes->inicio;
    	while(itera != NULL){
            agente_t * remove = itera;
            itera = itera->ant;
            //libera cada agente
            removeAgente(agentes, remove);
        }
    }
    agentes = (lista_agentes *) malloc(sizeof(lista_agentes));
    iniciaListaAgentes(agentes);
    handleAgente();

    // se a lista de pocas nao for nula, o seu espaco de memoria deve ser liberado
    if (pocas != NULL) {
	poca_t * itera = pocas->inicio;
    	while(itera != NULL){
            poca_t * remove = itera;
            itera = itera->ant;
            //libera cada poca
            removePoca(pocas, remove);
        }
    }
    pocas = (lista_pocas *) malloc(sizeof(lista_pocas));
    iniciaListaPocas(pocas);
    criaPocasIniciais(pocas);

    // se a lista de mosquitos nao for nula, o seu espaco de memoria deve ser liberado
    if (mosquitos != NULL) {
	mosquito_t * itera = mosquitos->inicio;
    	while(itera != NULL){
            mosquito_t * remove = itera;
            itera = itera->ant;
            //libera cada mosquito
            removeMosquito(mosquitos, remove);
        }
    }
    mosquitos = (lista_mosquitos *) malloc(sizeof(lista_mosquitos));
    iniciaListaMosquitos(mosquitos);
    criaMosquitosIniciais(mosquitos,NUM_MOSQUITOS);

    modo = PAUSE;
    animados = false;

}

// funcao para processar teclas digitadas
void processNormalKeys(unsigned char key, int x, int y)
{

	if (key == 27) // ESC sai
	        exit(0);
	if(key == 32) // ESPACO reinicia jogo
		RESET();
	if(key == 13){
		if(modo == PAUSE)
			modo = RUN;
		else
			modo = PAUSE;
	}
}

// funcao para inicializar as variaveis do opengl e carregar texturas
void InitializeOGL()
{
    // inicializa variaveis do opengl
    RESET();
    glClearColor(0.0,0.0,0.0,0.0);
    glHint(GL_PERSPECTIVE_CORRECTION_HINT,GL_NICEST);
    glShadeModel(GL_SMOOTH);
    glBlendFunc(GL_SRC_ALPHA,GL_ONE_MINUS_SRC_ALPHA);
    glEnable(GL_BLEND);

    // texturas
    glEnable(GL_TEXTURE_2D);
    CreateTexture(texturas,"imagens/agente/00.tga",0);
    CreateTexture(texturas,"imagens/agente/01.tga",1);
    CreateTexture(texturas,"imagens/agente/02.tga",2);
    CreateTexture(texturas,"imagens/agente/03.tga",3);
    CreateTexture(texturas,"imagens/agente/04.tga",4);
    CreateTexture(texturas,"imagens/agente/05.tga",5);
    CreateTexture(texturas,"imagens/agente/06.tga",6);
    CreateTexture(texturas,"imagens/agente/07.tga",7);
    CreateTexture(texturas,"imagens/agente/08.tga",8);
    CreateTexture(texturas,"imagens/agente/09.tga",9);
    CreateTexture(texturas,"imagens/agente/10.tga",10);
    CreateTexture(texturas,"imagens/background.tga",11);
    CreateTexture(texturas,"imagens/gameover.tga",12); // texto gameover
    CreateTexture(texturas,"imagens/spray.tga",13); // fumaca spray
    CreateTexture(texturas,"imagens/vitoria.tga",14); // texto vitoria
    CreateTexture(texturas,"imagens/area_hospital.tga",15); // zona hospital
    CreateTexture(texturas,"imagens/area_municao.tga",16); // zona spray
    CreateTexture(texturas,"imagens/go_u.tga",17); // botao goal inativado (apagar)
    CreateTexture(texturas,"imagens/goal.tga",18); // goal
    CreateTexture(texturas,"imagens/poca.tga",19); // textura poca de agua
    CreateTexture(texturas,"imagens/life.tga",20); // cor life
    CreateTexture(texturas,"imagens/debug.tga",21); // background debug
    CreateTexture(texturas,"imagens/highlight.tga",22); // highlight agente (nao tem mais)
    CreateTexture(texturas,"imagens/barra_spray.tga",23); // cor barra spray
    CreateTexture(texturas,"imagens/mosquito/00.tga",24);
    CreateTexture(texturas,"imagens/mosquito/01.tga",25);



    return;
}

// funcao para processar teclas especiais (F1,F2 etc)
void glutSpecial(int value, int x, int y)
{
    switch (value)
    {
        case GLUT_KEY_F3:
        printf("PIXELS: x %d,y %d\n",x,y); // debug: imprime posicao do mouse no console
        printf("RELATIVO: x %f,y %f\n",((float)x * 0.00625)-2,2 - (float)y * 0.00625); // debug: imprime posicao do mouse no console
        printf("FPS: %d\n",fps);
	printf("teste geraCoord: %G\n", geraCoordenada());
    }
}

//init VSync func
#ifdef _WIN32
void InitVSync()
{
   //get extensions of graphics card
   char* extensions = (char*)glGetString(GL_EXTENSIONS);

   //is WGL_EXT_swap_control in the string? VSync switch possible?
   if (strstr(extensions,"WGL_EXT_swap_control"))
   {
      //get address's of both functions and save them
      wglSwapIntervalEXT = (PFNWGLEXTSWAPCONTROLPROC)
          wglGetProcAddress("wglSwapIntervalEXT");
      wglGetSwapIntervalEXT = (PFNWGLEXTGETSWAPINTERVALPROC)
          wglGetProcAddress("wglGetSwapIntervalEXT");
  }
}
#endif

int main(int argc, char **argv)
{

    glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_DEPTH | GLUT_DOUBLE | GLUT_RGBA);
    glutInitWindowPosition(100,100);
    glutInitWindowSize(640,640);
    glutCreateWindow("Dengue FSM Demo");
    glutDisplayFunc(renderScene);
    glutIdleFunc(renderScene);
    glutReshapeFunc(changeSize);
    glutKeyboardFunc(processNormalKeys);
    glutSpecialFunc(glutSpecial);
    glutMouseFunc(processMouse);
    glutMotionFunc(processMouseActiveMotion);
    glutPassiveMotionFunc(processMousePassiveMotion);


    InitializeOGL();
//#ifdef _WIN32
//    InitVSync();
//    wglSwapIntervalEXT(0); // disable vsync
//#endif
    glutMainLoop();
}
