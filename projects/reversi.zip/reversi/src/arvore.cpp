#include "arvore.h"
#include "lista.h"

//inicializa arvore com o nodo raiz
void iniciaArvore(arvore_t * arvore, nodo_t * raiz){
	arvore->raiz = raiz;
}

void insereFilho(nodo_t * pai, nodo_t * filho) {
	filho->nivel = pai->nivel + 1;		
	pai->num_filhos++;
	adicionaLista(pai->filhos, filho);
}

nodo_t * criaNodo(nodo_t * pai, int valor, int casa_i, int casa_j) {
	nodo_t * nodo = (nodo_t *) malloc(sizeof(nodo_t));	
	nodo->valor = valor;
	nodo->num_filhos = 0;
	nodo->nivel = -1;
	nodo->casa_i = casa_i;
	nodo->casa_j = casa_j;
	nodo->alfabeta = NULL;
	nodo->pretas = 0;
	nodo->brancas = 0;
	nodo->pai = pai;
	
	//inicializa a lista de filhos
	nodo->filhos = (lista_t *) malloc(sizeof(lista_t));	
	iniciaLista(nodo->filhos);
	
	return nodo;
}

//metodo recursivo para dar um free em toda uma arvore a partir da raiz 
void freeArvore(nodo_t * raiz) {
	if (raiz != NULL) {
		if (raiz->num_filhos == 0) {//se nao tem filho libera a raiz
			raiz->prox = NULL;
			raiz->ant = NULL;
		//	free(raiz->filhos);//libera a lista de filhos
		//	free(raiz);
		} else {//se tem filho 
			nodo_t * itera = raiz->filhos->fim;
			nodo_t * apaga;
			while (itera != NULL) {
				apaga = itera; 
				itera = itera->prox;	
				freeArvore(apaga);							
				//free(apaga->filhos);
				freeNodo(apaga);
				raiz->num_filhos--;
				raiz->filhos->numNodos--;
			}
			//free(raiz->filhos);//libera a lista de filhos		
			//free(raiz);
		}
	} else {
		printf("[Reversi] #ERRO# Chamou freeArvore para raiz nula.\n");
	}
}

void freeNodo(nodo_t * nodo){
	nodo->alfabeta = NULL;
	nodo->prox = NULL;
	nodo->ant = NULL;
	nodo->pai = NULL;
	nodo->filhos->inicio = NULL;
	nodo->filhos->fim = NULL;
	free(nodo->filhos);
	free(nodo);
}
