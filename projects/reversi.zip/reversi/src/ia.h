#ifndef _ia_h
#define _ia_h

#include "arvore.h"
#include "casa.h"
#include "lista.h"

#define PIOR_DIF -1000
#define MELHOR_DIF 1000

void calculaJogadasPossiveis(int tabuleiroPai[8][8],nodo_t * nodoPai, int nivelCorte, int nivelRaiz, int cor);
bool simulaTroca(int * casa);
void contaPecas(nodo_t *nodo);
void simulaJogada(int tabuleiro[8][8], nodo_t *nodo, unsigned int cor, int casa_i, int casa_j);
void podaAlfaBeta(nodo_t * pai, nodo_t * filho);
int utilidade(int tabuleiro[8][8]);
#endif
