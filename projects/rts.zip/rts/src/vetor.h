#ifndef _VETOR_H
#define _VETOR_H

#include <math.h>
#include <stdlib.h>

typedef struct vetor2d
{
  float x, y;

}vetor2d;

typedef struct polar
{
	float thet,raio;
}polar;

vetor2d * novoVetor(float x, float y);
vetor2d * calculaVetor(vetor2d* pontoInicio, vetor2d* pontoFim);
vetor2d * somaVetor(vetor2d* a, vetor2d* b);
//void multiplicaVetor(struct vetor2d* vetor, struct vetor2d* v, struct vetor2d* w);
void multiplicaEscalar(vetor2d* vetor, float escalar);
float norma(vetor2d* vetor);
void normalizaVetor(vetor2d* vetor);
vetor2d * pol2cart(polar* pol);
polar * cart2pol(vetor2d* cart);
//bool proximo(struct vetor2d A, struct vetor2d B, float delta);

void freeVetor(vetor2d *);
void freePolar(polar *);


#endif
