====================================================
Dengue Fever Mosquito Exterminator
Finite State Machine Example
====================================================
Author: Vinicius Marques Terra
====================================================

    
Introduction
------------------------

This is a 2D goal oriented game featuring a finite-state machine (FSM) for enemy behavior.
This demo also includes simple heath and ammo implementation.


Controls
------------------------

Space : reset game / randomize position for the mosquitoes and water puddles.
Return : Start game.
left mouse button:  set goal for the character.
right mouse button: release spray to kill near mosquitoes.
ESC : exit game.

How to play
------------------------

Kill all the mosquitoes before they deplete the character's health. As the time passes,
the mosquites can stop on a pubble and reproduce, generating another mosquito. The game 
ends  successifuly when all mosquitoes are killed. The game is over when the mosquitoes 
depletes the player health. Stop above the two areas on the bottom screen to restore 
health and ammo:

	- First area (Red cross) - Restore health.
	- Second area (Gun)- Restore spray ammo.
