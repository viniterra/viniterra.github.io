#include "obstaculo.h"

obstaculo_t * criaObstaculo(float X1, float Y1, float X2, float Y2, float X3, float Y3, float X4, float Y4){
    obstaculo_t * obs = (obstaculo_t *) malloc(sizeof(obstaculo_t));

    obs->X1 = X1; obs->Y1 = Y1;
    obs->X2 = X2; obs->Y2 = Y2;
    obs->X3 = X3; obs->Y3 = Y3;
    obs->X4 = X4; obs->Y4 = Y4;

    obs->prox = NULL;
    obs->ant = NULL;

    return obs;
}

void iniciaListaObstaculos(lista_obstaculos * lista){
        lista->inicio = NULL;
        lista->fim = NULL;
        lista->numObstaculos = 0;
}

void adicionaObstaculo(lista_obstaculos * lista, obstaculo_t * novo_obstaculo){
                novo_obstaculo->prox = lista->fim;
                novo_obstaculo->ant = NULL;
                if(lista->inicio == NULL)
                        lista->inicio = novo_obstaculo;
                if(lista->fim != NULL)
                        lista->fim->ant = novo_obstaculo;
                lista->fim = novo_obstaculo;
                lista->numObstaculos++;
}

//retira obstaculo da lista
void removeObstaculo(lista_obstaculos * lista,  obstaculo_t * obstaculo) {
	if(lista != NULL && obstaculo != NULL) {
		if(lista->numObstaculos > 0) {
			if(obstaculo == lista->inicio) {
				lista->inicio = obstaculo->ant;
			}
			if(obstaculo == lista->fim) {
				lista->fim = obstaculo->prox;
			}
			if (obstaculo->prox != NULL) {
				obstaculo->prox->ant = obstaculo->ant;
			}
			if(obstaculo->ant != NULL) {
				obstaculo->ant->prox = obstaculo->prox;
			}
			lista->numObstaculos--;
			free(obstaculo);
		}
	} else {
		printf("[Obstaculo.cpp][RemoveObstaculos] ERROR!! Null pointer received!\n");
	}	
}

