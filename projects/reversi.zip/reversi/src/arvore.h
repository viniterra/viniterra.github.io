#ifndef _arvore_h
#define _arvore_h

#include <stdlib.h>
#include "casa.h"


typedef struct nodo_t{
	int valor;
	int nivel; //nivel da arvore que o nodo esta
	int num_filhos;
	int tabuleiro[8][8];
	int brancas;//numero de pecas
	int pretas;// numero de pecas
	int casa_i,casa_j; // coordenadas da casa da jogada
	
        struct nodo_t * alfabeta; // melhor escolha
	struct nodo_t * pai;//pai do nodo	
       	struct lista_t * filhos; //lista de nodos filhos 							
	struct nodo_t * prox;//ponteiro utilizado na 
	struct nodo_t * ant;//lista em que ele pertence (lista no nodo pai)
} nodo_t;


typedef struct arvore_t{
	nodo_t * raiz;
} arvore_t; 

void iniciaArvore(arvore_t * arvore, nodo_t * raiz);
void insereFilho(nodo_t * pai, nodo_t * filho);
void freeArvore(nodo_t * raiz);
void freeNodo(nodo_t * nodo);
nodo_t * criaNodo(nodo_t * pai, int valor, int casa_i, int casa_j);

#endif
