====================================================
Reversi (Othello) Game
====================================================
Author: Vinicius Marques Terra
====================================================

    
Introduction
------------------------

This is an implementation of the Reversi board game. Reversi is a strategy board game for two
players, played on an 8x8 board. This demo features an opponent A.I. with Minimax, a decision
rule for two-player zero-sum game theory.


Controls
------------------------

Left mouse button: place disk piece (click on on valid position)
Space : reset game (main menu)
ESC : exit game

How to play
------------------------

On main menu, click on the following modes to begin a new game:
	- 'F�cil': Click to select easy difficulty mode
	- 'M�dio': Click to select medium difficulty mode
	- 'Dif�cil': Click to select hard difficulty mode

When the game starts, click on a valid position to place a disk piece. Wait for 
the opponent turn to end to play again. The game ends when there is no valid 
place for any disk piece on the board. The side with more pieces on the board 
wins.
