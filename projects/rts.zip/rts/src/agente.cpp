#include "agente.h"

agente_t * criaAgente(float X, float Y, float ang, float frame, float goalX, float goalY){
	agente_t * agente = (agente_t *) malloc(sizeof(agente_t));
	agente->posX = X;
	agente->posY = Y;

	agente->goalX = goalX;
	agente->goalY = goalY;

	agente->ang = ang;
	agente->frame = frame;

	agente->selected = true;
	agente->andando = false;

	agente->prox = NULL;
	agente->ant = NULL;

	return agente;
}

void iniciaListaAgentes(lista_agentes * lista){
        lista->inicio = NULL;
        lista->fim = NULL;
        lista->numAgentes = 0;
}

void adicionaAgente(lista_agentes * lista, agente_t * novo_agente){
	novo_agente->prox = lista->fim;
        novo_agente->ant = NULL;
        if(lista->inicio == NULL)
        	lista->inicio = novo_agente;
        if(lista->fim != NULL)
        	lista->fim->ant = novo_agente;
        lista->fim = novo_agente;
        lista->numAgentes++;
}


//retira agente da lista
void removeAgente(lista_agentes * lista,  agente_t * agente) {
	if(lista != NULL && agente != NULL) {
		if(lista->numAgentes > 0) {
			if(agente == lista->inicio) {
				lista->inicio = agente->ant;
			}
			if(agente == lista->fim) {
				lista->fim = agente->prox;
			}
			if (agente->prox != NULL) {
				agente->prox->ant = agente->ant;
			}
			if(agente->ant != NULL) {
				agente->ant->prox = agente->prox;
			}
			lista->numAgentes--;
			free(agente);
		}
	} else {
		printf("[Agente.h][RemoveAgente] ERROR!! Null pointer received!\n");
	}	
}


