====================================================
Goal Seeker / RTS Controller
====================================================
Author: Vinicius Marques Terra
====================================================

    
Introduction
------------------------

This is a demo featuring 2D controller for goal oriented Real-time strategy like games.
Main features:

 - Dynamic ambient setup: agents and obstacle creation.
 - Independent behavior: select which agents to control in real-time.
 - Obstacle avoidance.


How to play:
------------------------

Use the three buttons on the bottom screen menu to navigate through modes:

	- First menu button ('A') - Agents mode - Place agents on the field.
	- Second menu button (Square) - Obstacle mode - Place obstacles on the field.
	- Third menu button (Crosshair) - Simulation mode - Begin simulation.


Controls
------------------------

Left mouse button: place agents (agents mode), create obstacles (obstacle mode), select agents (simulation mode).
Right mouse button: set goal for selected agents (simulation mode).
Space : reset game.
Esc : exit game.
