#include "vetor.h"

// operacoes com vetores

vetor2d * novoVetor(float x, float y){
	vetor2d * vetor = (vetor2d *) malloc(sizeof(vetor2d));
	
	vetor->x = x;
	vetor->y = y;

	return vetor;
}

vetor2d * calculaVetor(vetor2d* pontoInicio, vetor2d* pontoFim){
	vetor2d * vetor = (vetor2d *) malloc(sizeof(vetor2d));
	
	vetor->x = pontoFim->x - pontoInicio->x;
	vetor->y = pontoFim->y - pontoInicio->y;

	return vetor;
}

vetor2d * somaVetor(vetor2d * a, vetor2d * b){
	vetor2d * vetor = (vetor2d *) malloc(sizeof(vetor2d));

	vetor->x = a->x + b->x;
	vetor->y = a->y + b->y;

	return vetor;
}
/*void multiplicaVetor(struct vetor3d* vetor, struct vetor3d* v, struct vetor3d* w){

		vetor->x = (v->y * w->z)-(v->z * w->y);
		vetor->y = -((v->x * w->z)-(v->z * w->x));
		vetor->z = (v->x * w->y)-(v->y * w->x);

}*/
void multiplicaEscalar(vetor2d * vetor, float escalar){
	vetor->x = vetor->x * escalar;
	vetor->y = vetor->y * escalar;
}

float norma(vetor2d * vetor){
	float norma = (vetor->x * vetor->x)+(vetor->y * vetor->y);
	norma = sqrtf(norma);

	return norma;
}

void normalizaVetor(vetor2d * vetor){

	float fator = norma(vetor);
	if(fator != 0)
		fator = 1/fator;
	vetor->x = vetor->x * fator;
	vetor->y = vetor->y * fator;
}

vetor2d * pol2cart(polar * pol){
	vetor2d * cart = (vetor2d *) malloc(sizeof(vetor2d));
	
	//converter coordenadas polares em cartesianas
	const float PI = 3.14159265;
	// seno e coseno em radianos (isso me custou umas 4 horas)
	cart->x = pol->raio * cos(pol->thet *PI/180);// x = r . cos(thet)
	cart->y = pol->raio * sin(pol->thet *PI/180); // y = r . sen(thet)

	return cart;
}

polar * cart2pol(vetor2d * cart){
    polar * pol = (polar *) malloc(sizeof(polar));

    // converter coordenadas cartesianas em polares
    const float PI = 3.14159265;
    pol->raio = sqrt(cart->x*cart->x + cart->y*cart->y); // r = raiz(x^2 + y^2)

    pol->thet = 2 * atanf((cart->y/pol->raio) / (1 + (cart->x/pol->raio))); // thet = 2 arctan( y/r / 1+x/r)
    
    pol->thet = pol->thet *180/PI;

    return pol;
}

void freeVetor(vetor2d * vetor) {
	vetor->x = 0;
	vetor->y = 0;	
	free(vetor);
}

void freePolar(polar * pol) {
	pol->thet = 0;
	pol->raio = 0;	
	free(pol);
}	


