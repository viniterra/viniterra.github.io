#ifndef _CASA_H
#define _CASA_H

#define PRETA 0
#define BRANCA 1
#define VAZIA 2

#include<GL/glut.h>
#include <stdlib.h>
#include <stdio.h>


// a casa e um quadrado do tabuleiro
typedef struct casa
{
  float x_ini, y_ini, x_fim, y_fim; // coordenadas em pixel da casa, iniciais e finais
  float x_relativo, y_relativo; // coordenadas (nao sao em pixel) do centro da casa relativo ao centro da janela, o ponto 0,0
  unsigned int statusCasa; //status da casa: PRETA,BRANCA,VAZIA
}casa;

bool mouseEstaNaCasa(casa casa, float x, float y); // se o ponteiro esta na casa
bool criarPeca(casa tabuleiro[8][8], int casa_i, int casa_j, bool liberada, int cor); // cria peca da cor passada como parametro na casa
bool trocarPeca(casa *casa); // troca peca existente na casa para outra cor
void realizaJogada(casa tabuleiro[8][8], unsigned int cor, int casa_i, int casa_j); // troca as pecas decorrentes da jogada realizada

#endif

