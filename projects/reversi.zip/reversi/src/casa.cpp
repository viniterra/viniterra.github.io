#include "casa.h"

bool mouseEstaNaCasa(casa casa, float x, float y){ // se o mouse esta na casa
     if(casa.x_ini<= x && x <= casa.x_fim)
                     if(casa.y_ini <= y && y<= casa.y_fim)
                                   return true;
     return false;
}


bool criarPeca(casa tabuleiro[8][8], int casa_i, int casa_j, bool liberada, int cor){ // cria peca da cor passada como parametro na casa
    if(liberada){
        tabuleiro[casa_i][casa_j].statusCasa = cor;
	realizaJogada(tabuleiro, cor, casa_i, casa_j);
        return true;
    }
    else{
        printf("\nCasa invalida!\n");
        return false;
    }
}


bool trocarPeca(casa *casa){; // troca peca existente na casa para outra cor
    if(casa->statusCasa == PRETA){
        casa->statusCasa = BRANCA;
        return true;
    }
    else if(casa->statusCasa == BRANCA){
        casa->statusCasa = PRETA;
        return true;
    }
    return false;
}


//colore as pecas apos a jogada
void realizaJogada(casa tabuleiro[8][8], unsigned int cor, int casa_i, int casa_j) {

	int vizinho_i,vizinho_j;
	
	//verifica vizinho 1
	vizinho_i = casa_i;
	vizinho_j = casa_j - 1;	
	//confere se a casa esta dentro do tabuleiro
	if (vizinho_i >= 0 && vizinho_i < 8 && vizinho_j >= 0 && vizinho_j < 8) {
		//se o vizinho for de cor diferente
		if (tabuleiro[vizinho_i][vizinho_j].statusCasa == !cor)	{
			//enquanto nao chegar na borda verifica o vizinho ao lado
			while (vizinho_j > 0) {
				vizinho_j--;
				// achou o vizinho de mesma cor
				if (tabuleiro[vizinho_i][vizinho_j].statusCasa == cor)	{
					// volta trocando a cor das pecas
					while(vizinho_j < casa_j-1){
						vizinho_j++;
						trocarPeca(&tabuleiro[vizinho_i][vizinho_j]);
					}
					break;
				} else if (tabuleiro[vizinho_i][vizinho_j].statusCasa == VAZIA) {
					break;
				}	
			}		
		}	
	}
	//verifica vizinho 2
	vizinho_i = casa_i - 1;
	vizinho_j = casa_j - 1;	
	//confere se a casa esta dentro do tabuleiro
	if (vizinho_i >= 0 && vizinho_i < 8 && vizinho_j >= 0 && vizinho_j < 8) {
		//se o vizinho for de cor diferente
		if (tabuleiro[vizinho_i][vizinho_j].statusCasa == !cor)	{
			//enquanto nao chegar na borda verifica o vizinho ao lado
			while (vizinho_i > 0 && vizinho_j > 0) {
				vizinho_i--; vizinho_j--; 
				// achou vizinho da mesma cor
				if (tabuleiro[vizinho_i][vizinho_j].statusCasa == cor)	{
					// volta trocando a cor das pecas
					while(vizinho_i < casa_i-1 && vizinho_j < casa_j-1){
						vizinho_i++; vizinho_j++;
						trocarPeca(&tabuleiro[vizinho_i][vizinho_j]);
					}
					break;
				} else if (tabuleiro[vizinho_i][vizinho_j].statusCasa == VAZIA) {
					break;
				}	
			}		
		}	
	}
	//verifica vizinho 3
	vizinho_i = casa_i - 1;
	vizinho_j = casa_j;	
	//confere se a casa esta dentro do tabuleiro
	if (vizinho_i >= 0 && vizinho_i < 8 && vizinho_j >= 0 && vizinho_j < 8) {
		//se o vizinho for de cor diferente
		if (tabuleiro[vizinho_i][vizinho_j].statusCasa == !cor)	{
			//enquanto nao chegar na borda verifica o vizinho ao lado
			while (vizinho_i > 0) {
				vizinho_i--;
				if (tabuleiro[vizinho_i][vizinho_j].statusCasa == cor)	{
					// volta trocando a cor das pecas
					while(vizinho_i < casa_i-1){
						vizinho_i++;
						trocarPeca(&tabuleiro[vizinho_i][vizinho_j]);
					}
					break;
				} else if (tabuleiro[vizinho_i][vizinho_j].statusCasa == VAZIA) {
					break;
				}	
			}		
		}	
	}
	//verifica vizinho 4
	vizinho_i = casa_i - 1;
	vizinho_j = casa_j + 1;	
	//confere se a casa esta dentro do tabuleiro
	if (vizinho_i >= 0 && vizinho_i < 8 && vizinho_j >= 0 && vizinho_j < 8) {
		//se o vizinho for de cor diferente
		if (tabuleiro[vizinho_i][vizinho_j].statusCasa == !cor)	{
			//enquanto nao chegar na borda verifica o vizinho ao lado
			while (vizinho_i > 0 && vizinho_j < 7) {
				vizinho_i--; vizinho_j++; 
				if (tabuleiro[vizinho_i][vizinho_j].statusCasa == cor)	{
					// volta trocando a cor das pecas
					while(vizinho_i < casa_i-1 && vizinho_j > casa_j+1){
						vizinho_i++; vizinho_j--;
						trocarPeca(&tabuleiro[vizinho_i][vizinho_j]);
					}
					break;
				} else if (tabuleiro[vizinho_i][vizinho_j].statusCasa == VAZIA) {
					break;
				}	
			}		
		}	
	}
	//verifica vizinho 5
	vizinho_i = casa_i;
	vizinho_j = casa_j + 1;	
	//confere se a casa esta dentro do tabuleiro
	if (vizinho_i >= 0 && vizinho_i < 8 && vizinho_j >= 0 && vizinho_j < 8) {
		//se o vizinho for de cor diferente
		if (tabuleiro[vizinho_i][vizinho_j].statusCasa == !cor)	{
			//enquanto nao chegar na borda verifica o vizinho ao lado
			while (vizinho_j < 7) {
				vizinho_j++;
				if (tabuleiro[vizinho_i][vizinho_j].statusCasa == cor)	{
					while(vizinho_j > casa_j+1){
						vizinho_j--;
						trocarPeca(&tabuleiro[vizinho_i][vizinho_j]);
					}
					break;
				} else if (tabuleiro[vizinho_i][vizinho_j].statusCasa == VAZIA) {
					break;
				}	
			}		
		}	
	}
	//verifica vizinho 6
	vizinho_i = casa_i + 1;
	vizinho_j = casa_j + 1;	
	//confere se a casa esta dentro do tabuleiro
	if (vizinho_i >= 0 && vizinho_i < 8 && vizinho_j >= 0 && vizinho_j < 8) {
		//se o vizinho for de cor diferente
		if (tabuleiro[vizinho_i][vizinho_j].statusCasa == !cor)	{
			//enquanto nao chegar na borda verifica o vizinho ao lado
			while (vizinho_i < 7 && vizinho_j < 7) {
				vizinho_i++; vizinho_j++; 
				if (tabuleiro[vizinho_i][vizinho_j].statusCasa == cor)	{
					while(vizinho_i > casa_i+1 && vizinho_j > casa_j+1){
						vizinho_i--; vizinho_j--;
						trocarPeca(&tabuleiro[vizinho_i][vizinho_j]);
					}
					break;
				} else if (tabuleiro[vizinho_i][vizinho_j].statusCasa == VAZIA) {
					break;
				}	
			}		
		}	
	}
	//verifica vizinho 7
	vizinho_i = casa_i + 1;
	vizinho_j = casa_j;	
	//confere se a casa esta dentro do tabuleiro
	if (vizinho_i >= 0 && vizinho_i < 8 && vizinho_j >= 0 && vizinho_j < 8) {
		//se o vizinho for de cor diferente
		if (tabuleiro[vizinho_i][vizinho_j].statusCasa == !cor)	{
			//enquanto nao chegar na borda verifica o vizinho ao lado
			while (vizinho_i < 7) {
				vizinho_i++;
				if (tabuleiro[vizinho_i][vizinho_j].statusCasa == cor)	{
					while(vizinho_i > casa_i+1){
						vizinho_i--;
						trocarPeca(&tabuleiro[vizinho_i][vizinho_j]);
					}
					break;
				} else if (tabuleiro[vizinho_i][vizinho_j].statusCasa == VAZIA) {
					break;
				}	
			}		
		}	
	}
	//verifica vizinho 8
	vizinho_i = casa_i + 1;
	vizinho_j = casa_j - 1;	
	//confere se a casa esta dentro do tabuleiro
	if (vizinho_i >= 0 && vizinho_i < 8 && vizinho_j >= 0 && vizinho_j < 8) {
		//se o vizinho for de cor diferente
		if (tabuleiro[vizinho_i][vizinho_j].statusCasa == !cor)	{
			//enquanto nao chegar na borda verifica o vizinho ao lado
			while (vizinho_i < 7 && vizinho_j > 0) {
				vizinho_i++; vizinho_j--; 
				if (tabuleiro[vizinho_i][vizinho_j].statusCasa == cor)	{
					// volta trocando a cor das pecas
					while(vizinho_i > casa_i+1 && vizinho_j < casa_j-1){
						vizinho_i--; vizinho_j++;
						trocarPeca(&tabuleiro[vizinho_i][vizinho_j]);
					}
					break;
				} else if (tabuleiro[vizinho_i][vizinho_j].statusCasa == VAZIA) {
					break;
				}	
			}		
		}	
	}

}	

