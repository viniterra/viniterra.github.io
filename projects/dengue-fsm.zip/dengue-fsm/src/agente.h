#ifndef _AGENTE_H
#define _AGENTE_H

#include <stdlib.h>
#include <stdio.h>

typedef struct agente_t
{
	float posX; // coordenada X relativa
	float posY; // coordenada Y relativa
	float ang; // angulo de rotacao
	float frame; //  quadro da animacao

	bool selected; // se o agente esta selecionado
	bool andando;

	float goalX; float goalY; // goal do agente

	float life; // vida do agente
	float spray; // arma do agente

	agente_t* prox;
	agente_t* ant;

}agente_t;

typedef struct lista_agentes
{
    agente_t* inicio;
    agente_t* fim;
    int numAgentes;
}lista_agentes;

agente_t * criaAgente(float X, float Y, float ang, float frame, float goalX, float goalY);
void iniciaListaAgentes(lista_agentes * lista);
void adicionaAgente(lista_agentes * lista, agente_t * novo_agente);
void removeAgente(lista_agentes * lista,  agente_t * agente);
#endif
