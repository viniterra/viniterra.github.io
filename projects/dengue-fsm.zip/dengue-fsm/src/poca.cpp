#include "poca.h"

poca_t * criaPoca(float X, float Y){
	poca_t * poca = (poca_t *) malloc(sizeof(poca_t));
	poca->posX = X;
	poca->posY = Y;

	poca->raio = RAIO;

	poca->ocupada = false;

	poca->prox = NULL;
	poca->ant = NULL;

	return poca;
}

void iniciaListaPocas(lista_pocas * lista){
        lista->inicio = NULL;
        lista->fim = NULL;
        lista->numPocas = 0;
}

void adicionaPoca(lista_pocas * lista, poca_t * nova_poca){
	nova_poca->prox = lista->fim;
        nova_poca->ant = NULL;
        if(lista->inicio == NULL)
        	lista->inicio = nova_poca;
        if(lista->fim != NULL)
        	lista->fim->ant = nova_poca;
        lista->fim = nova_poca;
        lista->numPocas++;
}


//retira poca da lista
void removePoca(lista_pocas * lista,  poca_t * poca) {
	if(lista != NULL && poca != NULL) {
		if(lista->numPocas > 0) {
			if(poca == lista->inicio) {
				lista->inicio = poca->ant;
			}
			if(poca == lista->fim) {
				lista->fim = poca->prox;
			}
			if (poca->prox != NULL) {
				poca->prox->ant = poca->ant;
			}
			if(poca->ant != NULL) {
				poca->ant->prox = poca->prox;
			}
			lista->numPocas--;
			free(poca);
		}
	} else {
		printf("[Poca.h][RemovePoca] ERROR!! Null pointer received!\n");
	}	
}

void criaPocasIniciais(lista_pocas * lista){
	for(int i=0;i<NUM_POCAS;i++){
		adicionaPoca(lista,criaPoca(geraCoordenada(),geraCoordenada()));
	}
}

