#ifndef _OBSTACULO_H
#define _OBSTACULO_H

#include <stdlib.h>
#include <stdio.h>

typedef struct obstaculo_t
{
//	X1,Y1 ######## X2,Y2
//    #              #
//    #              #
//    #              #
//    #              #
//    #              #
//	X4,Y4 ######## X3,Y3

	float X1,Y1;
	float X2,Y2;
	float X3,Y3;
	float X4,Y4;

	obstaculo_t* prox;
	obstaculo_t* ant;

}obstaculo_t;

typedef struct lista_obstaculos
{
    obstaculo_t* inicio;
    obstaculo_t* fim;
    int numObstaculos;
}lista_obstaculos;

obstaculo_t * criaObstaculo(float X1, float Y1, float X2, float Y2, float X3, float Y3, float X4, float Y4);
void iniciaListaObstaculos(lista_obstaculos * lista);
void adicionaObstaculo(lista_obstaculos * lista, obstaculo_t * novo_obstaculo);
void removeObstaculo(lista_obstaculos * lista,  obstaculo_t * obstaculo);
#endif
