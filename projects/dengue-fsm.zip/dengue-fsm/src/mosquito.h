#ifndef _MOSQUITO_H
#define _MOSQUITO_H

#include <stdlib.h>
#include <stdio.h>
#include "functions.h"
#include "poca.h"
#include "vetor.h"
#include "agente.h"

#define NUM_MOSQUITOS 7

#define ANDANDO 1
#define ATACANDO 2
#define FUGINDO 3
#define REPRODUZINDO 4

#define PERTO_WAYPOINT 0.2
#define PARADO 0.016
#define DIST_ATAQUE 0.4

#define TEMPO_CLONAGEM 50.0
#define TEMPO_SEM_REPRODUZIR 100.0

typedef struct mosquito_t
{
	float posX; // coordenada X relativa
	float posY; // coordenada Y relativa
	float ang; // angulo de rotacao
	float frame; //  quadro da animacao

	float tc; // tempo para clonagem	
	float tr; // tempo que o mosquito deve ficar sem reproduzir 

	bool atacou; // se o mosquito ja atacou e agora tem que reproduzir para atacar novamente
	bool andando;

	short estado;

	float goalX; float goalY; // goal do mosquito

	float tempoAtaque; // tempo de atacando o player

	float life;

	mosquito_t* prox;
	mosquito_t* ant;
	
	poca_t * pocaProxima; // poca mais proxima do mosquito

}mosquito_t;

typedef struct lista_mosquitos
{
    mosquito_t* inicio;
    mosquito_t* fim;
    int numMosquitos;
}lista_mosquitos;

mosquito_t * criaMosquito(float X, float Y, float ang, float frame, float goalX, float goalY);
void iniciaListaMosquitos(lista_mosquitos * lista);
void criaMosquitosIniciais(lista_mosquitos * lista, int numMosquitos);
void adicionaMosquito(lista_mosquitos * lista, mosquito_t * novo_mosquito);
void removeMosquito(lista_mosquitos * lista,  mosquito_t * mosquito);
void atacarAlvo(mosquito_t * mosquito, int fps, float * velMAX, lista_mosquitos * lista, agente_t * jogador);
void fugirMosquito(mosquito_t * itera, lista_mosquitos * lista, agente_t * jogador, int fps, float * velMAX, lista_pocas * pocas);
void voaMosquito(mosquito_t * itera, lista_mosquitos * lista, int fps, float * velMAX, agente_t * jogador, lista_pocas * pocas);
void reproduzir(mosquito_t * mosquito, lista_mosquitos * lista, int fps, lista_pocas * pocas);
void handleFSM(mosquito_t * mosquito, lista_mosquitos * lista, int fps, float * velMAX, agente_t * jogador, lista_pocas * pocas);
#endif
