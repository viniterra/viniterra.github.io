#include "mosquito.h"

mosquito_t * criaMosquito(float X, float Y, float ang, float frame, float goalX, float goalY){
	mosquito_t * mosquito = (mosquito_t *) malloc(sizeof(mosquito_t));
	mosquito->posX = X;
	mosquito->posY = Y;

	mosquito->goalX = goalX;
	mosquito->goalY = goalY;

	mosquito->ang = ang;
	mosquito->frame = frame;

	mosquito->andando = true;

	mosquito->tempoAtaque = 0;

	mosquito->life = 100.0;

	mosquito->estado = ANDANDO;

	mosquito->pocaProxima = NULL;

	mosquito->tc = 0;
	mosquito->tr = 0;

	mosquito->prox = NULL;
	mosquito->ant = NULL;

	return mosquito;
}

void iniciaListaMosquitos(lista_mosquitos * lista){
        lista->inicio = NULL;
        lista->fim = NULL;
        lista->numMosquitos = 0;
}

void criaMosquitosIniciais(lista_mosquitos * lista, int numMosquitos){
	for(int i=0;i<numMosquitos;i++){
		mosquito_t * mosquito = criaMosquito(geraCoordenada(),geraCoordenada(),0,(i%2),geraCoordenada(),geraCoordenada());
		adicionaMosquito(lista, mosquito);
	}
}

void adicionaMosquito(lista_mosquitos * lista, mosquito_t * novo_mosquito){
	novo_mosquito->prox = lista->fim;
        novo_mosquito->ant = NULL;
        if(lista->inicio == NULL)
        	lista->inicio = novo_mosquito;
        if(lista->fim != NULL)
        	lista->fim->ant = novo_mosquito;
        lista->fim = novo_mosquito;
        lista->numMosquitos++;
}


//retira mosquito da lista
void removeMosquito(lista_mosquitos * lista,  mosquito_t * mosquito) {
	if(lista != NULL && mosquito != NULL) {
		if(lista->numMosquitos > 0) {
			if(mosquito == lista->inicio) {
				lista->inicio = mosquito->ant;
			}
			if(mosquito == lista->fim) {
				lista->fim = mosquito->prox;
			}
			if (mosquito->prox != NULL) {
				mosquito->prox->ant = mosquito->ant;
			}
			if(mosquito->ant != NULL) {
				mosquito->ant->prox = mosquito->prox;
			}
			lista->numMosquitos--;
			free(mosquito);
		}
	} else {
		printf("[Mosquito.h][RemoveMosquito] ERROR!! Null pointer received!\n");
	}
}

void atacarAlvo(mosquito_t * mosquito, int fps, float * velMAX, lista_mosquitos * lista, agente_t * jogador){
	*velMAX = 1.5/(float)fps; // velocidade maxima
	// parametros repulsao atracao
	float A = 0.01;
	float B = 0.0000001;
	float m = 4;
	float n = 1.5;
	// faz mosquito ir ate alvo (atracao)
	vetor2d * posicao = novoVetor(mosquito->posX, mosquito->posY);
	vetor2d * goal = novoVetor(mosquito->goalX, mosquito->goalY);
	vetor2d * caminhar = calculaVetor(posicao, goal); // vetor que define a distancia do agente para o goal
	float r = norma(caminhar);
	float atr = A * n/pow(r,n); //A* pow(r,n); // atracao r^2
	normalizaVetor(caminhar);
	multiplicaEscalar(caminhar, atr);

	// para cada outro mosquito vizinho (repulsao)
	mosquito_t * vizinho = lista->inicio;
	while(vizinho != NULL){
		if(vizinho != mosquito){ // nao e o proprio mosquito
			vetor2d * posVizinho = novoVetor(vizinho->posX, vizinho->posY); // posicao do vizinho
			vetor2d * distVizinho = calculaVetor(posVizinho,posicao); // sai do vizinho aponta pro mosquito
			float rVizinho = norma(distVizinho);
			float rep = B * m/pow(rVizinho,m); // repulsao
			normalizaVetor(distVizinho);
			multiplicaEscalar(distVizinho,rep);

			caminhar = somaVetor(caminhar,distVizinho); // soma a repulsao para este vizinho

			freeVetor(posVizinho);
			freeVetor(distVizinho);
		}
		vizinho = vizinho->ant;
	}


	float velocidade = norma(caminhar);

	if(velocidade > *velMAX){ // verifica se velocidade nao ultrapassa velocidade maxima
		normalizaVetor(caminhar);
		multiplicaEscalar(caminhar,*velMAX); // passar por valor
	}

	polar * pol = cart2pol(caminhar);

	mosquito->ang = pol->thet + 90;

	mosquito->posX += caminhar->x; // soma delta a posicao do mosquito
	mosquito->posY += caminhar->y;

	// transicoes de estado
	if(r <= PERTO_WAYPOINT){ // chegou no alvo
		mosquito->tempoAtaque += 20/(float)fps;
		// faz mosquito fugir
		if(mosquito->tempoAtaque > 10){ // acabou tempo ataque
			jogador->life -= 5.0;
			mosquito->goalX = geraCoordenada();
			mosquito->goalY = geraCoordenada();
			mosquito->tempoAtaque = 0;
			mosquito->estado = FUGINDO;
		}
	}

	freeVetor(posicao);
	freeVetor(goal);
	freeVetor(caminhar);

}

void fugirMosquito(mosquito_t * itera, lista_mosquitos * lista, agente_t * jogador, int fps, float * velMAX, lista_pocas * pocas){
	*velMAX = 1.5/(float)fps; // velocidade maxima
	// parametros repulsao e atracao
	float A = 0.01;
	float B = 0.0000001;
	float m = 4;
	float n = 1.5;

	// faz mosquito ir ate goal (atracao)
	vetor2d * posicao = novoVetor(itera->posX, itera->posY);
	vetor2d * goal = novoVetor(itera->goalX, itera->goalY);
	vetor2d * caminhar = calculaVetor(posicao, goal); // vetor que define a distancia do agente para o goal
	float r = norma(caminhar);
	float atr = A* pow(r,n); // atracao r^2
	normalizaVetor(caminhar);
	multiplicaEscalar(caminhar, atr);

	// faz mosquito fugir do jogador (repulsao)
	goal = novoVetor(jogador->posX, jogador->posY);
	vetor2d * fugir = calculaVetor(goal, posicao); // vetor que define a distancia do agente para o goal
	float rFuga = norma(fugir);
	float repJogador = (3*B) * m/pow(rFuga,m); // repulsao
	normalizaVetor(fugir);
	multiplicaEscalar(fugir, repJogador);

	caminhar = somaVetor(caminhar, fugir); // soma contribuicao da repulsao no vetor resultante

	// para cada outro mosquito vizinho (repulsao)
	mosquito_t * vizinho = lista->inicio;
	while(vizinho != NULL){
		if(vizinho != itera){ // nao e o proprio mosquito
			vetor2d * posVizinho = novoVetor(vizinho->posX, vizinho->posY); // posicao do vizinho
			vetor2d * distVizinho = calculaVetor(posVizinho,posicao); // sai do vizinho aponta pro mosquito
			float rVizinho = norma(distVizinho);
			float rep = B * m/pow(rVizinho,m); // repulsao
			normalizaVetor(distVizinho);
			multiplicaEscalar(distVizinho,rep);

			caminhar = somaVetor(caminhar,distVizinho); // soma a repulsao para este vizinho

			freeVetor(posVizinho);
			freeVetor(distVizinho);
		}
		vizinho = vizinho->ant;
	}

	float velocidade = norma(caminhar);

	if(velocidade > *velMAX){ // verifica se velocidade nao ultrapassa velocidade maxima
		normalizaVetor(caminhar);
		multiplicaEscalar(caminhar,*velMAX); // passar por valor
	}

	polar * pol = cart2pol(caminhar);

	itera-> ang = pol->thet + 90;

	itera->posX += caminhar->x; // soma delta a posicao do mosquito
	itera->posY += caminhar->y;

	// transicoes de estado

	if(r <= PERTO_WAYPOINT){
			itera->goalX = geraCoordenada();
			itera->goalY = geraCoordenada();
			itera->estado = ANDANDO;
	}

	poca_t * iteraPoca = pocas->inicio;
	vetor2d *  posicaoPoca;
	vetor2d * distancia;
	if(itera->tr <= 0){ // venceu tempo sem reproduzir
		while(iteraPoca !=NULL){
			posicaoPoca = novoVetor(iteraPoca->posX, iteraPoca->posY);
			distancia = calculaVetor(posicao,posicaoPoca);
			float distPoca = norma(distancia);

			freeVetor(posicaoPoca);
			freeVetor(distancia);

			if(distPoca <= PERTO_POCA && iteraPoca->ocupada == false){ // esta perto da poca
				iteraPoca->ocupada = true;
				itera->pocaProxima = iteraPoca;
				itera->estado = REPRODUZINDO;
				break;
			}

			iteraPoca = iteraPoca->ant;
		}
	}
	else{ //decrementa tempo sem reproduzir
		itera->tr -= 20/(float)fps;
	}


	freeVetor(posicao);
	freeVetor(goal);
	freeVetor(caminhar);

}

void voaMosquito(mosquito_t * itera, lista_mosquitos * lista, int fps, float * velMAX, agente_t * jogador, lista_pocas * pocas){

	*velMAX = 1.5/(float)fps; // velocidade maxima
	// parametros repulsao e atracao
	float A = 0.01;
	float B = 0.0000001;
	float m = 4;
	float n = 1.5;
	// faz agente ir ate goal (atracao)
	vetor2d * posicao = novoVetor(itera->posX, itera->posY);
	vetor2d * goal = novoVetor(itera->goalX, itera->goalY);
	vetor2d * caminhar = calculaVetor(posicao, goal); // vetor que define a distancia do mosquito para o goal
	float r = norma(caminhar);
	if(r <= PERTO_WAYPOINT){ // chegou no waypoint
		itera->goalX = geraCoordenada();
		itera->goalY = geraCoordenada();
		goal = novoVetor(itera->goalX, itera->goalY); // define novo waypoint
		caminhar = calculaVetor(posicao, goal);
		r = norma(caminhar);
	}
	float atr = A* pow(r,n); // atracao r^2
	normalizaVetor(caminhar);
	multiplicaEscalar(caminhar, atr);

	// para cada outro mosquito vizinho (repulsao)
	mosquito_t * vizinho = lista->inicio;
	while(vizinho != NULL){
		if(vizinho != itera){ // nao e o proprio mosquito
			vetor2d * posVizinho = novoVetor(vizinho->posX, vizinho->posY); // posicao do vizinho
			vetor2d * distVizinho = calculaVetor(posVizinho,posicao); // sai do vizinho aponta pro mosquito
			float rVizinho = norma(distVizinho);
			float rep = B * m/pow(rVizinho,m); // repulsao
			normalizaVetor(distVizinho);
			multiplicaEscalar(distVizinho,rep);

			caminhar = somaVetor(caminhar,distVizinho); // soma a repulsao para este vizinho

			freeVetor(posVizinho);
			freeVetor(distVizinho);
		}
		vizinho = vizinho->ant;
	}

	float velocidade = norma(caminhar);

	if(velocidade > *velMAX){ // verifica se velocidade nao ultrapassa velocidade maxima
		normalizaVetor(caminhar);
		multiplicaEscalar(caminhar,*velMAX); // passar por valor
	}

	polar * pol = cart2pol(caminhar);

	itera-> ang = pol->thet + 90;

	itera->posX += caminhar->x; // soma delta a posicao do mosquito
	itera->posY += caminhar->y;

	// transicoes de estado
	// verifica se esta a uma distancia boa para atacar
	goal = novoVetor(jogador->posX, jogador->posY);
	vetor2d * distAlvo = calculaVetor(posicao, goal);
	float rAlvo = norma(distAlvo);

	if(rAlvo <= DIST_ATAQUE){
	    itera->pocaProxima = NULL;
		itera->estado = ATACANDO;
	}

	else{
		poca_t * iteraPoca = pocas->inicio;
		vetor2d *  posicaoPoca;
		vetor2d * distancia;
		if(itera->tr <= 0){ // venceu tempo sem reproduzir
			while(iteraPoca !=NULL){
				posicaoPoca = novoVetor(iteraPoca->posX, iteraPoca->posY);
				distancia = calculaVetor(posicao,posicaoPoca);
				float distPoca = norma(distancia);

				freeVetor(posicaoPoca);
				freeVetor(distancia);

				if(distPoca <= PERTO_POCA && iteraPoca->ocupada == false){ // esta perto da poca
					iteraPoca->ocupada = true;
					itera->pocaProxima = iteraPoca;
					itera->estado = REPRODUZINDO;
					break;
				}

				iteraPoca = iteraPoca->ant;
			}
		}
		else{ //decrementa tempo sem reproduzir
			itera->tr -= 20/(float)fps;
		}
	}


	freeVetor(posicao);
	freeVetor(goal);
	freeVetor(caminhar);
	freeVetor(distAlvo);

}

void reproduzir(mosquito_t * mosquito, lista_mosquitos * lista, int fps, lista_pocas * pocas) {
	if(mosquito->pocaProxima != NULL){
		if(mosquito->tc < TEMPO_CLONAGEM){
			mosquito->tc += 20/(float)fps;
		}
		else{
		// cria novo mosquito
		mosquito_t * novoMosquito = criaMosquito(mosquito->posX+0.1,mosquito->posY+0.1,0,0,geraCoordenada(),geraCoordenada());
		adicionaMosquito(lista, novoMosquito);
		// remove poca
		removePoca(pocas, mosquito->pocaProxima);
		// cria nova poca
		poca_t * novaPoca = criaPoca(geraCoordenada(),geraCoordenada());
		adicionaPoca(pocas, novaPoca);

		// seta tempo sem reproduzir de ambos mosquitos
		mosquito->pocaProxima = NULL;
		mosquito->tr = TEMPO_SEM_REPRODUZIR;
		mosquito->tc = 0;
		mosquito->estado = ANDANDO;

		novoMosquito->pocaProxima = NULL;
		novoMosquito->tr = 0;
		novoMosquito->tc = 0;
		novoMosquito->estado = ANDANDO;
		}
	}
	else{
		mosquito->estado = ANDANDO;
	}
}

// maquina de estados do mosquito
void handleFSM(mosquito_t * mosquito, lista_mosquitos * lista, int fps, float * velMAX, agente_t * jogador, lista_pocas * pocas){
	switch(mosquito->estado){
		// mosquito voando
		case ANDANDO:
			// codigo seguir waypoint
			voaMosquito(mosquito,lista,fps, velMAX, jogador, pocas);
			break;
		case ATACANDO:
			// seta goal como o jogador - alvo a ser atacado
			mosquito->goalX = jogador->posX;
			mosquito->goalY = jogador->posY;
			atacarAlvo(mosquito, fps,  velMAX, lista, jogador);
			break;
		case FUGINDO:
			fugirMosquito(mosquito, lista, jogador, fps, velMAX, pocas);
			break;
		case REPRODUZINDO:
			reproduzir(mosquito, lista, fps, pocas);
			break;
	}
}

