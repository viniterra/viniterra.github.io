#ifndef _POCA_H
#define _POCA_H

#include <stdlib.h>
#include <stdio.h>
#include "functions.h"

#define RAIO 0.5
#define PERTO_POCA 0.2
#define NUM_POCAS 5

typedef struct poca_t
{
	float posX; // coordenada X relativa
	float posY; // coordenada Y relativa

	float raio;// raio da poca

	bool ocupada; // mosquito esta usando a poca

	poca_t* prox;
	poca_t* ant;

}poca_t;

typedef struct lista_pocas
{
    poca_t* inicio;
    poca_t* fim;
    int numPocas;
}lista_pocas;

poca_t * criaPoca(float X, float Y);
void iniciaListaPocas(lista_pocas * lista);
void adicionaPoca(lista_pocas * lista, poca_t * nova_poca);
void removePoca(lista_pocas * lista,  poca_t * poca);
void criaPocasIniciais(lista_pocas * lista);
#endif
