#include "lista.h"

void iniciaLista(lista_t* lista){
        lista->inicio = NULL;
        lista->fim = NULL;
        lista->numNodos = 0;
}

void adicionaLista(lista_t * lista, nodo_t * nodo_novo){
                nodo_novo->prox = lista->fim;
                nodo_novo->ant = NULL;
                if(lista->inicio == NULL)
                        lista->inicio = nodo_novo;
                if(lista->fim != NULL)
                        lista->fim->ant = nodo_novo;
                lista->fim = nodo_novo;
                lista->numNodos++;
}

/*void retiraLista(lista_t * lista, nodo_t * nodo){
        if(lista->numNodos > 0){
                nodo_t * tmp = lista->fim;
                while(tmp != NULL && tmp->id != nodo->id) //encontra servidor a ser removido
                        tmp = tmp->prox;
                if(tmp != NULL){
                        if(tmp == lista->inicio)
                                lista->inicio = tmp->ant;
                        if(tmp == lista->fim)
                                lista->fim = tmp->prox;
                        if (tmp->prox != NULL)
                                tmp->prox->ant = tmp-> ant;
                        if(tmp->ant != NULL)
                                tmp->ant->prox = tmp->prox;
                }
                lista->numNodos--;
                free(tmp);
        }
}*/

