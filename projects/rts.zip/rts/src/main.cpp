#include<GL/glut.h>
#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>

#include "tga.h"
#include "agente.h"
#include "obstaculo.h"
#include "vetor.h"

#include <iostream>
#include <cstdarg>


#define BT_AGENTE 1
#define BT_OBSTACULO 2
#define BT_GOAL 3

#define PARADO 0.016

short botao;

enum {
    BUTTON_LEFT = 0,
    BUTTON_RIGHT,
    BUTTON_LEFT_TRANSLATE,
};

// coordenadas do goal
float goalX, goalY;
float rotGoal;

// variaveis do obstaculo sendo criado
bool sendoCriado;
float X[2]; float Y[2];
int indiceVertice;
float mouseX[2], mouseY[2];


// variaveis
int mButton = -1;
float width,height;
bool selecionando;
float selectX[2], selectY[2];
float selTempX[2], selTempY[2];
int indiceVertSel;

// lista de agentes
lista_agentes * agentes = NULL;

// lista de obstaculos
lista_obstaculos * obstaculos = NULL;

int i,j;
GLuint texturas[24]; // arranjo com texturasa para desenhar

// frame rate
int fps = 0;
int frame=0,tempo,tempoBase=0;

// status dos agentes
bool animados;
float vel; // velocidade dos agentes

void calcularFPS(){
    frame++;
    tempo = glutGet(GLUT_ELAPSED_TIME);

    if (tempo - tempoBase > 1000) {
        fps = (int) frame*1000/(tempo-tempoBase);
        tempoBase = tempo;
        frame = 0;
    }
}

//funcao pra redimensionar a janela (redimensionamento travado)
void changeSize(int w, int h)
{

    if(h!=640 && w!=640)
        glutReshapeWindow(640,640);
    width = w;
    height = h;
    float ratio = 1.0* w / h;
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    glViewport(0, 0, w, h);
    gluPerspective(45,ratio,1,1000);
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
    gluLookAt(0.0,0.0,5.0,
              0.0,0.0,-1.0,
              0.0f,1.0f,0.0f);
}

void animaAgentes(){
    agente_t * itera = agentes->inicio;
    while(itera != NULL){
        itera->frame+=(12/(float)fps); // anda frame agente
        if(itera->frame >=11)
            itera->frame -=10;
        itera = itera->ant;
    }
    // anima goal
    rotGoal += 230/(float)fps;
    if(rotGoal > 359)
	    rotGoal -= 359;
}

void desenhaBotoes(bool ag, bool ob, bool go){
    // desenha botao agentes
    glPushMatrix();
        glBindTexture(GL_TEXTURE_2D, texturas[13-(int)ag]);
        glTranslatef(-0.4,-1.87,0.0);
        glBegin(GL_QUADS);
            glNormal3f( 0.0f, 0.0f, 1.0f);
            glTexCoord2f(0.0f, 0.0f);glVertex3f(-0.2f, -0.2f,  0.0f);
            glTexCoord2f(1.0f, 0.0f);glVertex3f( 0.2f, -0.2f,  0.0f);
            glTexCoord2f(1.0f, 1.0f);glVertex3f( 0.2f,  0.2f,  0.0f);
            glTexCoord2f(0.0f, 1.0f);glVertex3f(-0.2f,  0.2f,  0.0f);
        glEnd();
    glPopMatrix();

    // desenha botao obstaculos
    glPushMatrix();
        glBindTexture(GL_TEXTURE_2D, texturas[15-(int)ob]);
        glTranslatef(0.0,-1.87,0.0);
        glBegin(GL_QUADS);
            glNormal3f( 0.0f, 0.0f, 1.0f);
            glTexCoord2f(0.0f, 0.0f);glVertex3f(-0.2f, -0.2f,  0.0f);
            glTexCoord2f(1.0f, 0.0f);glVertex3f( 0.2f, -0.2f,  0.0f);
            glTexCoord2f(1.0f, 1.0f);glVertex3f( 0.2f,  0.2f,  0.0f);
            glTexCoord2f(0.0f, 1.0f);glVertex3f(-0.2f,  0.2f,  0.0f);
        glEnd();
    glPopMatrix();

    // desenha botao goal
    glPushMatrix();
        glBindTexture(GL_TEXTURE_2D, texturas[17-(int)go]);
        glTranslatef(0.4,-1.87,0.0);
        glBegin(GL_QUADS);
            glNormal3f( 0.0f, 0.0f, 1.0f);
            glTexCoord2f(0.0f, 0.0f);glVertex3f(-0.2f, -0.2f,  0.0f);
            glTexCoord2f(1.0f, 0.0f);glVertex3f( 0.2f, -0.2f,  0.0f);
            glTexCoord2f(1.0f, 1.0f);glVertex3f( 0.2f,  0.2f,  0.0f);
            glTexCoord2f(0.0f, 1.0f);glVertex3f(-0.2f,  0.2f,  0.0f);
        glEnd();
    glPopMatrix();
}

float maior(float a1, float a2, float a3, float a4){
	if(a1 != a2){
		if(a1 > a2)
			return a1;
		else
			return a2;
	}
	else{
		if(a1 > a4)
			return a1;
		else
			return a4;
	}
}

float menor(float a1, float a2, float a3, float a4){
	if(a1 != a2){
		if(a1 < a2)
			return a1;
		else
			return a2;
	}
	else{
		if(a1 < a4)
			return a1;
		else
			return a4;
	}
}

typedef struct lado_t{
	float iteraIni;
	float iteraFim;
	float fixa;
	char ladoItera;
}lado;

// lado do obstaculo mais proximo do agente
lado_t * ladoMaisProximo(vetor2d * posicao, obstaculo_t * obst){

	lado_t * lado = (lado_t *) malloc(sizeof(lado_t));

	float xMaior,xMenor,yMaior,yMenor; // x > e y ^

	// funcao para definir os valores de x e y maior e menor
	xMaior = maior(obst->X1,obst->X2,obst->X3,obst->X4);
	xMenor = menor(obst->X1,obst->X2,obst->X3,obst->X4);
	yMaior = maior(obst->Y1,obst->Y2,obst->Y3,obst->Y4);
	yMenor = menor(obst->Y1,obst->Y2,obst->Y3,obst->Y4);

	float delta = 0.1; // tamanho da iteracao

	float norm = 1000000.0f;


	vetor2d * ponto;
	vetor2d * distPonto;


	// x aumenta com y maior
	for(float i = xMenor; i <= xMaior; i+=delta){
		ponto = novoVetor(i,yMaior);
		distPonto = calculaVetor(ponto,posicao);
		if(norma(distPonto) < norm){
			norm = norma(distPonto);
		       	lado->fixa = yMaior;
			lado->iteraIni = xMenor;
			lado->iteraFim = xMaior;
			lado->ladoItera = 'x';
		}
	}
	// y diminui com x maior
	for(float i = yMaior; i >= yMenor; i-=delta){
		ponto = novoVetor(xMaior,i);
		distPonto = calculaVetor(ponto,posicao);
		if(norma(distPonto) < norm){
			norm = norma(distPonto);
		       	lado->fixa = xMaior;
			lado->iteraIni = yMenor;
			lado->iteraFim = yMaior;
			lado->ladoItera = 'y';
		}
	}
	// x diminui com y menor
	for(float i = xMaior; i >= xMenor; i-=delta){
		ponto = novoVetor(i,yMenor);
		distPonto = calculaVetor(ponto,posicao);
		if(norma(distPonto) < norm){
			norm = norma(distPonto);
		       	lado->fixa = yMenor;
			lado->iteraIni = xMenor;
			lado->iteraFim = xMaior;
			lado->ladoItera = 'x';

		}
	}
	// y aumenta com x menor
	for(float i = yMenor; i <= yMaior; i+=delta){
		ponto = novoVetor(xMenor,i);
		distPonto = calculaVetor(ponto,posicao);
		if(norma(distPonto) < norm){
			norm = norma(distPonto);
			lado->fixa = xMenor;
			lado->iteraIni = yMenor;
			lado->iteraFim = yMaior;
			lado->ladoItera = 'y';
		}
	}


	return lado;
}

// funcao de movimentacao: atualiza posicao dos agentes
void caminhaAgentes(){
	vel = 1.5/(float)fps;
	// para cada agente
	agente_t * itera = agentes->inicio;
	float A = 0.01;
	float B = 0.0000001;
	float m = 4;
	float n = 1.5;
	while(itera != NULL){
		// faz agente ir ate goal
		vetor2d * posicao = novoVetor(itera->posX, itera->posY);
		vetor2d * goal = novoVetor(itera->goalX, itera->goalY);
		vetor2d * caminhar = calculaVetor(posicao, goal); // vetor que define a distancia do agente para o goal
		float r = norma(caminhar);
		float atr = A* pow(r,n); // r^2
//	       	float rep = r- (B * m/pow(r,m)); // - 4/r^4
		normalizaVetor(caminhar);
		multiplicaEscalar(caminhar, atr);

		// para cada outro agente vizinho
		agente_t * vizinho = agentes->inicio;
		while(vizinho != NULL){
			if(vizinho != itera){ // nao e o proprio agente
				vetor2d * posVizinho = novoVetor(vizinho->posX, vizinho->posY); // posicao do vizinho
				vetor2d * distVizinho = calculaVetor(posVizinho,posicao); // sai do vizinho aponta pro agente
				float rVizinho = norma(distVizinho);
				float rep = B * m/pow(rVizinho,m);
				normalizaVetor(distVizinho);
				multiplicaEscalar(distVizinho,rep);

				caminhar = somaVetor(caminhar,distVizinho); // soma a repulsao para este vizinho

				freeVetor(posVizinho);
				freeVetor(distVizinho);
			}
			vizinho = vizinho->ant;
		}

		// para cada obstaculo
		obstaculo_t * obst = obstaculos->inicio;
		while(obst != NULL){
			lado_t * lado = ladoMaisProximo(posicao,obst); // lado mais proximo do agente
			// soma forcas do lado no agente
			if(lado->ladoItera == 'x'){
				for(float i=lado->iteraIni;i<lado->iteraFim;i+=0.1){ // itera o x
					vetor2d * posObst = novoVetor(i,lado->fixa);
					vetor2d * distObst = calculaVetor(posObst,posicao); // sai do obstaculo aponta pro agente
					float rObst = norma(distObst);
					float rep = B * (m+1)/pow(rObst,(m+1));
					normalizaVetor(distObst);
					multiplicaEscalar(distObst,rep);

					caminhar = somaVetor(caminhar,distObst); // soma a repulsao para este obstaculo

					freeVetor(posObst);
					freeVetor(distObst);

				}
			}
			else{
				for(float i=lado->iteraIni;i<lado->iteraFim;i+=0.1){ // itera o y
					vetor2d * posObst = novoVetor(lado->fixa,i);
					vetor2d * distObst = calculaVetor(posObst,posicao); // sai do obstaculo aponta pro agente
					float rObst = norma(distObst);
					float rep = B * (m+1)/pow(rObst,(m+1));
					normalizaVetor(distObst);
					multiplicaEscalar(distObst,rep);

					caminhar = somaVetor(caminhar,distObst); // soma a repulsao para este obstaculo

					freeVetor(posObst);
					freeVetor(distObst);

				}

			}

			free(lado);

			obst = obst->ant;
		}

		float velocidade = norma(caminhar);

		if(velocidade > vel){ // verifica se velocidade nao ultrapassa velocidade maxima
			normalizaVetor(caminhar);
			multiplicaEscalar(caminhar,vel);
		}
		if(velocidade < PARADO / (float)fps)
			itera->andando = false;
		else
			itera->andando = true;

		polar * pol = cart2pol(caminhar);

		itera-> ang = pol->thet + 90;

		itera->posX += caminhar->x; // soma delta a posicao do agente
		itera->posY += caminhar->y;

		freeVetor(posicao);
		freeVetor(goal);
		freeVetor(caminhar);

		itera = itera->ant;
	}
}

// funcao pra desenhar os sprites na tela
void renderScene(void)
{

    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

    //  desenha backgound
    glBindTexture(GL_TEXTURE_2D, texturas[11+ (10*(int)!animados)]);
    glBegin(GL_QUADS);
        glNormal3f( 0.0f, 0.0f, 1.0f);
        glTexCoord2f(0.0f, 0.0f);glVertex3f(-3.0f, -3.0f,  -2.0f);
        glTexCoord2f(10.0f, 0.0f);glVertex3f( 3.0f, -3.0f,  -2.0f);
        glTexCoord2f(10.0f, 10.0f);glVertex3f( 3.0f,  3.0f,  -2.0f);
        glTexCoord2f(0.0f, 10.0f);glVertex3f(-3.0f,  3.0f,  -2.0f);
    glEnd();

    // desenha goal
    glPushMatrix();
    glBindTexture(GL_TEXTURE_2D, texturas[18]);
    glTranslatef(goalX,goalY,0.0);
    glRotatef(rotGoal,0.0,0.0,1.0);
    glBegin(GL_QUADS);
        glNormal3f( 0.0f, 0.0f, 1.0f);
        glTexCoord2f(0.0f, 0.0f);glVertex3f(-0.1f, -0.1f,  0.0f);
        glTexCoord2f(1.0f, 0.0f);glVertex3f( 0.1f, -0.1f,  0.0f);
        glTexCoord2f(1.0f, 1.0f);glVertex3f( 0.1f,  0.1f,  0.0f);
        glTexCoord2f(0.0f, 1.0f);glVertex3f(-0.1f,  0.1f,  0.0f);
    glEnd();
    glPopMatrix();

    //  desenha agentes
    agente_t * itera = agentes->inicio;
    while(itera != NULL){

        // highlight do agente selecionado
        if(itera->selected){
            glPushMatrix();
            glBindTexture(GL_TEXTURE_2D, texturas[22]);
            glTranslatef(itera->posX,itera->posY,0.0);
            glBegin(GL_QUADS);
                glNormal3f( 0.0f, 0.0f, 1.0f);
                glTexCoord2f(0.0f, 0.0f);glVertex3f(-0.1f, -0.1f,  0.0f);
                glTexCoord2f(1.0f, 0.0f);glVertex3f( 0.1f, -0.1f,  0.0f);
                glTexCoord2f(1.0f, 1.0f);glVertex3f( 0.1f,  0.1f,  0.0f);
                glTexCoord2f(0.0f, 1.0f);glVertex3f(-0.1f,  0.1f,  0.0f);
            glEnd();
            glPopMatrix();
        }
        //agente
        glPushMatrix();
            glBindTexture(GL_TEXTURE_2D, texturas[(int)(itera->frame) * (int) animados * itera->andando]);
            glTranslatef(itera->posX,itera->posY,0.0);
            glRotatef(itera->ang, 0.0,0.0,1.0);
            glBegin(GL_QUADS);
                glNormal3f( 0.0f, 0.0f, 1.0f);
                glTexCoord2f(0.0f, 0.0f);glVertex3f(-0.06f, -0.1f,  0.0f);
                glTexCoord2f(0.99f, 0.0f);glVertex3f( 0.06f, -0.1f,  0.0f);
                glTexCoord2f(0.99f, 0.99f);glVertex3f( 0.06f,  0.1f,  0.0f);
                glTexCoord2f(0.0f, 0.99f);glVertex3f(-0.06f,  0.1f,  0.0f);
            glEnd();
        glPopMatrix();
        itera = itera->ant;
    }

    // desenha obstaculos
    obstaculo_t * iteraObs = obstaculos->inicio;
     while(iteraObs != NULL){
        glPushMatrix();
        glBindTexture(GL_TEXTURE_2D, texturas[19]);
        glBegin(GL_QUADS);
            glNormal3f( 0.0f, 0.0f, 1.0f);
            glTexCoord2f(0.0f, 0.0f);glVertex3f(iteraObs->X1, iteraObs->Y1,  0.0f);
            glTexCoord2f(1.0f, 0.0f);glVertex3f(iteraObs->X2, iteraObs->Y2,  0.0f);
            glTexCoord2f(1.0f, 1.0f);glVertex3f(iteraObs->X3, iteraObs->Y3,  0.0f);
            glTexCoord2f(0.0f, 1.0f);glVertex3f(iteraObs->X4, iteraObs->Y4,  0.0f);
        glEnd();
        glPopMatrix();
        iteraObs = iteraObs->ant;
    }
    // desenha objeto sendo criado
    if(sendoCriado){
        glPushMatrix();
        glBindTexture(GL_TEXTURE_2D, texturas[20]);
        glBegin(GL_QUADS);
            glNormal3f( 0.0f, 0.0f, 1.0f);
            glTexCoord2f(0.0f, 0.0f);glVertex3f(mouseX[0], mouseY[0],  0.0f);
            glTexCoord2f(1.0f, 0.0f);glVertex3f(mouseX[1], mouseY[0],  0.0f);
            glTexCoord2f(1.0f, 1.0f);glVertex3f(mouseX[1], mouseY[1],  0.0f);
            glTexCoord2f(0.0f, 1.0f);glVertex3f(mouseX[0], mouseY[1],  0.0f);
        glEnd();
        glPopMatrix();
    }

    // desenha selecao agentes
    if(selecionando){
        glPushMatrix();
        glBindTexture(GL_TEXTURE_2D, texturas[23]);
        glBegin(GL_LINE_LOOP);
            glNormal3f( 0.0f, 0.0f, 1.0f);
            glTexCoord2f(0.0f, 0.0f);glVertex3f(selTempX[0], selTempY[0],  0.0f);
            glTexCoord2f(1.0f, 0.0f);glVertex3f(selTempX[1], selTempY[0],  0.0f);
            glTexCoord2f(1.0f, 1.0f);glVertex3f(selTempX[1], selTempY[1],  0.0f);
            glTexCoord2f(0.0f, 1.0f);glVertex3f(selTempX[0], selTempY[1],  0.0f);
        glEnd();
        glPopMatrix();
    }

    if(botao == BT_AGENTE){
        animados = false;
        desenhaBotoes(true,false,false);
    }
    else if(botao == BT_OBSTACULO){
        animados = false;
        desenhaBotoes(false,true,false);
    }
    else if(botao == BT_GOAL){
        animados = true;
        desenhaBotoes(false,false,true);
        animaAgentes();
	caminhaAgentes();
    }

    calcularFPS();
    glutSwapBuffers();

}

void setaBotao(int x, int y){
    // Agente
    if(x >= 228 && x <= 288
    && y >= 580 && y <= 640)
        botao = BT_AGENTE;

    // Obstaculo
    if(x >= 288 && x <= 350
    && y >= 580 && y <= 640)
        botao = BT_OBSTACULO;

    // Goal
    if(x >= 350 && x <= 410
    && y >= 580 && y <= 640)
        botao = BT_GOAL;
}

void handleAgente(int x, int y){
	int frame = ((x + y) % 10) + 1; // frame randomico
	agente_t * agente = criaAgente((((float)x * 0.00625)-2), (2-(float)y * 0.00625), (x+y)%360, frame, goalX, goalY);
	adicionaAgente(agentes,agente);
}

void handleObstaculo(int x, int y){
    if(!sendoCriado){ // nenhum obstaculo esta sendo criado
        sendoCriado = true; // abre criacao de novo obstaculo
        indiceVertice = 0;
        for(int i=0;i<2;i++){
            X[i] = 0;
            Y[i] = 0;
        }
    }
    if(sendoCriado){
        X[indiceVertice] = ((float)x * 0.00625)-2; // X relativo
        Y[indiceVertice] = (2-(float)y * 0.00625); // Y relativo

        if(indiceVertice == 0 ){ // primeiro ponto
            for(int i=0;i<2;i++){
                mouseX[i] = ((float)x * 0.00625)-2;
                mouseY[i] = (2-(float)y * 0.00625);
            }
            indiceVertice++;
        }
        else{ // segundo ponto, fecha objeto
            obstaculo_t * obst = criaObstaculo(X[0],Y[0],X[1],Y[0],X[1],Y[1],X[0],Y[1]);
            adicionaObstaculo(obstaculos,obst);
            sendoCriado = false;
        }
    }
}

void setaAgentesSelecionados(float xa,float xb, float ya, float yb){
    float xIni, xFim, yIni, yFim;
    // seta x e y de inicio a fim
    if(xa < xb){
        xIni = xa;
        xFim = xb;
    }
    else{
        xIni = xb;
        xFim = xa;
    }
    if(ya < yb){
        yIni = ya;
        yFim = yb;
    }
    else{
        yIni = yb;
        yFim = ya;
    }
    // percorre agentes e  verifica se estao na area de selecao
    agente_t * itera = agentes->inicio;
    while(itera != NULL){
            if(itera->posX >= xIni && itera->posX <= xFim
            && itera->posY >= yIni && itera->posY <= yFim){
                itera->selected = true;
            }
            else{
                itera->selected = false;
            }
            itera = itera->ant;
    }
}

void selecionaAgentes(int x, int y){
    if(!selecionando){ // comecou a selecao
        selecionando = true; // abre selecao de agentes
        indiceVertSel = 0;
        for(int i=0;i<2;i++){
            selectX[i] = 0;
            selectY[i] = 0;
        }
    }
    if(selecionando){
        selectX[indiceVertSel] = ((float)x * 0.00625)-2; // X relativo
        selectY[indiceVertSel] = (2-(float)y * 0.00625); // Y relativo

        if(indiceVertSel == 0 ){ // primeiro ponto
            for(int i=0;i<2;i++){
                selTempX[i] = ((float)x * 0.00625)-2;
                selTempY[i] = (2-(float)y * 0.00625);
            }
            indiceVertSel++;
        }
        else{ // segundo ponto, fecha selecao
            // seta agentes dentro da area de selecao
            setaAgentesSelecionados(selectX[0],selectX[1],selectY[0],selectY[1]);
            selecionando = false;
        }
    }
}

// funcao para processar os cliques do mouse
void processMouse(int button, int state, int x, int y)
{


    if(state == GLUT_DOWN)
    {

        switch(button)
        {

            case GLUT_LEFT_BUTTON: // apertou botao esquerdo
            mButton = BUTTON_LEFT;
            if(x>= 228 && x<= 410
            && y>= 580 && y<= 640){
                setaBotao(x,y);
                sendoCriado = false;
                selecionando = false;
            }
            else if(botao == BT_AGENTE){ // modo criar agente
                handleAgente(x,y);
            }
            else if(botao == BT_OBSTACULO){
                handleObstaculo(x,y);
            }
            else if(botao == BT_GOAL){ // modo setar selecao
                selecionaAgentes(x,y);
            }

            break;

            case GLUT_RIGHT_BUTTON: // apertou botao direito
            //    mButton = BUTTON_RIGHT;
            if(botao == BT_OBSTACULO){
                sendoCriado = false;
            }
            else if(botao == BT_GOAL){ // modo setar goal
                if(selecionando)
                    selecionando = false;
                else{
                    goalX = ((float)x * 0.00625)-2; // X relativo
                    goalY = (2-(float)y * 0.00625); // Y relativo
                    // para cada agente ativo setar o goal
                    agente_t * itera = agentes->inicio;
                    while(itera != NULL){
                        if(itera->selected){ // agente esta selecionado
                            itera->goalX = goalX; // seta goal do agente
                            itera->goalY = goalY;
                        }
                        itera = itera->ant;
                    }
                }
            }

            break;

            case GLUT_MIDDLE_BUTTON: // apertou botao do meio
            break;
        }
    }
    else if (state == GLUT_UP)
    {}


    mButton = -1;

}

// funcoes para processar mouse em movimento (nao precisa)
void processMouseActiveMotion(int x, int y)
{}
void processMousePassiveMotion(int x, int y)
{
    if(sendoCriado){ // criando obstaculo
        mouseX[1] = ((float)x * 0.00625)-2; // coordenadas relativas do mouse
        mouseY[1] = (2-(float)y * 0.00625);
    }
    if(selecionando){ // selecionando agentes
        selTempX[1] = ((float)x * 0.00625)-2; // coordenadas relativas do mouse
        selTempY[1] = (2-(float)y * 0.00625);
    }

}

// funcao para reiniciar o jogo (lembrar de resetar novas variaveis)
void RESET()
{
    frame = 0; tempoBase = 0;
    // se a lista de agentes nao for nula, o seu espaco de memoria deve ser liberado
    if (agentes != NULL) {
	agente_t * itera = agentes->inicio;
    	while(itera != NULL){
            agente_t * remove = itera;
            itera = itera->ant;
            //libera cada agente
            removeAgente(agentes, remove);
        }
    }
    agentes = (lista_agentes *) malloc(sizeof(lista_agentes));
    iniciaListaAgentes(agentes);

    // se a lista de obstaculos nao for nula, o seu espaco de memoria deve ser liberado
    if (obstaculos != NULL) {
	obstaculo_t * itera = obstaculos->inicio;
    	while(itera != NULL){
            obstaculo_t * remove = itera;
            itera = itera->ant;
            removeObstaculo(obstaculos,remove);
        }
    }
    obstaculos = (lista_obstaculos *) malloc(sizeof(lista_obstaculos));
    iniciaListaObstaculos(obstaculos);
    mouseX[0] = 0; mouseX[1] = 0;
    mouseY[0] = 0; mouseY[1] = 0;

    selTempX[0] = 0; selTempX[1] = 0;
    selTempY[0] = 0; selTempY[1] = 0;

    botao = BT_AGENTE;
    goalX = 0; goalY = 0;
    animados = false;

    // reseta variaveis de criacao de obstaculo
    sendoCriado = false;
    selecionando = false;
    indiceVertice = 0;
    indiceVertSel = 0;
    for(int i=0;i<4;i++){
        X[i] = 0;
        Y[i] = 0;
    }
}

// funcao para processar teclas digitadas
void processNormalKeys(unsigned char key, int x, int y)
{

    if (key == 27) // ESC sai
        exit(0);
    if(key == 32) // ESPACO reinicia jogo
        RESET();
}

// funcao para inicializar as variaveis do opengl e carregar texturas
void InitializeOGL()
{
    // inicializa variaveis do opengl
    RESET();
    glClearColor(0.0,0.0,0.0,0.0);
    glHint(GL_PERSPECTIVE_CORRECTION_HINT,GL_NICEST);
    glShadeModel(GL_SMOOTH);
    glBlendFunc(GL_SRC_ALPHA,GL_ONE_MINUS_SRC_ALPHA);
    glEnable(GL_BLEND);

    // texturas
    glEnable(GL_TEXTURE_2D);
    CreateTexture(texturas,"imagens/agente/00.tga",0);
    CreateTexture(texturas,"imagens/agente/01.tga",1);
    CreateTexture(texturas,"imagens/agente/02.tga",2);
    CreateTexture(texturas,"imagens/agente/03.tga",3);
    CreateTexture(texturas,"imagens/agente/04.tga",4);
    CreateTexture(texturas,"imagens/agente/05.tga",5);
    CreateTexture(texturas,"imagens/agente/06.tga",6);
    CreateTexture(texturas,"imagens/agente/07.tga",7);
    CreateTexture(texturas,"imagens/agente/08.tga",8);
    CreateTexture(texturas,"imagens/agente/09.tga",9);
    CreateTexture(texturas,"imagens/agente/10.tga",10);
    CreateTexture(texturas,"imagens/background.tga",11);
    CreateTexture(texturas,"imagens/ag.tga",12); // botao agente ativado
    CreateTexture(texturas,"imagens/ag_u.tga",13); // botao agente inativado
    CreateTexture(texturas,"imagens/ob.tga",14); // botao obstaculo ativado
    CreateTexture(texturas,"imagens/ob_u.tga",15); // botao obstaculo inativado
    CreateTexture(texturas,"imagens/go.tga",16); // botao goal ativado
    CreateTexture(texturas,"imagens/go_u.tga",17); // botao goal inativado
    CreateTexture(texturas,"imagens/goal.tga",18); // goal
    CreateTexture(texturas,"imagens/obstaculo.tga",19); // textura obstaculo
    CreateTexture(texturas,"imagens/select.tga",20); // cor select
    CreateTexture(texturas,"imagens/debug.tga",21); // backgound debug
    CreateTexture(texturas,"imagens/highlight.tga",22); // highlight agente
    CreateTexture(texturas,"imagens/select_ag.tga",23); // cor select agentes


    return;
}

// funcao para processar teclas especiais (F1,F2 etc)
void glutSpecial(int value, int x, int y)
{
    switch (value)
    {
        case GLUT_KEY_F3:
        printf("PIXELS: x %d,y %d\n",x,y); // debug: imprime posicao do mouse no console
        printf("RELATIVO: x %f,y %f\n",((float)x * 0.00625)-2,2 - (float)y * 0.00625); // debug: imprime posicao do mouse no console
        printf("FPS: %d\n",fps);
    }
}

int main(int argc, char **argv)
{

    glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_DEPTH | GLUT_DOUBLE | GLUT_RGBA);
    glutInitWindowPosition(100,100);
    glutInitWindowSize(640,640);
    glutCreateWindow("RTS Goal Seeker Controller");
    glutDisplayFunc(renderScene);
    glutIdleFunc(renderScene);
    glutReshapeFunc(changeSize);
    glutKeyboardFunc(processNormalKeys);
    glutSpecialFunc(glutSpecial);
    glutMouseFunc(processMouse);
    glutMotionFunc(processMouseActiveMotion);
    glutPassiveMotionFunc(processMousePassiveMotion);

    InitializeOGL();
    glutMainLoop();
}
