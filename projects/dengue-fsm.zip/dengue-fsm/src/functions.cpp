#include "functions.h"


//Gera uma coordenada aleatoria na tela, entre -2 e 2.
float geraCoordenada() {
	int num = rand()%20000;
	bool negativo = (bool) (rand()%2);
	float result = ((float)num)/10000;
	if (negativo) {result = -result;}
	return result; 
}

//retorna a maior coordenada do obstaculo
float maior(float a1, float a2, float a3, float a4){
	if(a1 != a2){
		if(a1 > a2)
			return a1;
		else
			return a2;
	}
	else{
		if(a1 > a4)
			return a1;
		else
			return a4;
	}
}

//retorna a menor coordenada do obstaculo
float menor(float a1, float a2, float a3, float a4){
	if(a1 != a2){
		if(a1 < a2)
			return a1;
		else
			return a2;
	}
	else{
		if(a1 < a4)
			return a1;
		else
			return a4;
	}
}

